/* Diwali Universe 2026 — inline SVG artwork (shaded vector illustration with gradients for depth). */
(function () {
  'use strict';
  const U = window.U;
  const Art = (U.Art = {});

  const GOLD = '<linearGradient id="goldG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff0b0"/><stop offset=".5" stop-color="#f1b93a"/><stop offset="1" stop-color="#b3720f"/></linearGradient>';

  /* ---------------- Little Krishna ---------------- */
  Art.krishna = () => `
<svg viewBox="0 -14 200 300" class="god krishna" role="img" aria-label="Little Krishna playing the flute">
<defs>
  <radialGradient id="kSkin" cx=".35" cy=".28" r=".85"><stop offset="0" stop-color="#8fbaff"/><stop offset=".5" stop-color="#4a82e2"/><stop offset="1" stop-color="#274fa8"/></radialGradient>
  <linearGradient id="kDhoti" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffe98a"/><stop offset=".6" stop-color="#f6bd25"/><stop offset="1" stop-color="#d48d0b"/></linearGradient>
  <linearGradient id="kGold" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff0b0"/><stop offset=".5" stop-color="#f1b93a"/><stop offset="1" stop-color="#b3720f"/></linearGradient>
  <linearGradient id="kFlute" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#c98a4a"/><stop offset="1" stop-color="#6b3d17"/></linearGradient>
</defs>
<ellipse cx="100" cy="274" rx="62" ry="9" fill="rgba(0,0,0,.4)"/>
<g class="bob">
  <rect x="76" y="222" width="20" height="44" rx="10" fill="url(#kSkin)"/><rect x="104" y="222" width="20" height="44" rx="10" fill="url(#kSkin)"/>
  <ellipse cx="86" cy="268" rx="15" ry="7" fill="#2a4fa0"/><ellipse cx="114" cy="268" rx="15" ry="7" fill="#2a4fa0"/>
  <ellipse cx="100" cy="142" rx="34" ry="38" fill="url(#kSkin)"/>
  <path d="M66 166 Q100 180 134 166 L146 240 Q100 254 54 240 Z" fill="url(#kDhoti)"/>
  <path d="M82 176 Q80 214 74 242 M100 178 Q100 214 100 248 M118 176 Q120 214 126 242" stroke="#b9780a" stroke-opacity=".45" stroke-width="2.4" fill="none"/>
  <rect x="64" y="160" width="72" height="12" rx="6" fill="url(#kGold)"/>
  <path d="M74 118 Q100 156 126 118" stroke="#ffe3ee" stroke-width="7" stroke-dasharray="1 9" stroke-linecap="round" fill="none"/>
  <circle cx="100" cy="146" r="6" fill="url(#kGold)"/>
  <path d="M70 126 Q56 108 102 98" stroke="url(#kSkin)" stroke-width="15" stroke-linecap="round" fill="none"/>
  <path d="M130 126 Q154 116 150 86" stroke="url(#kSkin)" stroke-width="15" stroke-linecap="round" fill="none"/>
  <rect x="72" y="112" width="14" height="6" rx="3" fill="url(#kGold)" transform="rotate(-30 79 115)"/>
  <g class="headbob">
    <circle cx="57" cy="78" r="10" fill="#3d70cf"/><circle cx="143" cy="78" r="10" fill="#3d70cf"/>
    <circle cx="55" cy="92" r="4.5" fill="url(#kGold)"/><circle cx="145" cy="92" r="4.5" fill="url(#kGold)"/>
    <circle cx="100" cy="74" r="45" fill="url(#kSkin)"/>
    <path d="M55 68 Q58 22 100 20 Q142 22 145 68 Q130 44 100 47 Q70 44 55 68Z" fill="#171528"/>
    <circle cx="66" cy="58" r="7" fill="#171528"/><circle cx="134" cy="58" r="7" fill="#171528"/><circle cx="100" cy="42" r="6" fill="#171528"/>
    <path d="M62 48 Q100 33 138 48 L136 57 Q100 43 64 57Z" fill="url(#kGold)"/>
    <circle cx="100" cy="46" r="3.6" fill="#e03a5a"/>
    <path d="M100 34 Q109 10 103 -6" stroke="#2c8a55" stroke-width="2.4" fill="none" stroke-linecap="round"/>
    <ellipse cx="103" cy="-4" rx="10.5" ry="16" fill="#1f9d6a"/><ellipse cx="103" cy="-3" rx="7" ry="11" fill="#2a6fd0"/><ellipse cx="103" cy="-2" rx="4" ry="6" fill="#ffcf3a"/><ellipse cx="103" cy="-1" rx="1.9" ry="3.2" fill="#0e3a7a"/>
    <path d="M100 54 L100 63" stroke="#fff3c4" stroke-width="3.2" stroke-linecap="round"/>
    <g class="eyes"><g class="eye" style="transform-origin:84px 78px"><ellipse cx="84" cy="78" rx="9" ry="10.5" fill="#fff"/><circle cx="85" cy="80" r="6" fill="#1b1230"/><circle cx="87" cy="77" r="2.3" fill="#fff"/></g>
    <g class="eye" style="transform-origin:116px 78px"><ellipse cx="116" cy="78" rx="9" ry="10.5" fill="#fff"/><circle cx="115" cy="80" r="6" fill="#1b1230"/><circle cx="117" cy="77" r="2.3" fill="#fff"/></g></g>
    <path d="M74 64 Q84 59 93 64 M107 64 Q116 59 126 64" stroke="#171528" stroke-width="2.4" fill="none" stroke-linecap="round"/>
    <circle cx="72" cy="94" r="7.5" fill="#ff8fb0" opacity=".5"/><circle cx="128" cy="94" r="7.5" fill="#ff8fb0" opacity=".5"/>
    <path d="M97 90 Q100 93 103 90" stroke="#1f3f8f" stroke-width="2" fill="none" stroke-linecap="round"/>
  </g>
  <g class="flute"><path d="M97 98 L178 66" stroke="url(#kFlute)" stroke-width="7" stroke-linecap="round"/>
    <path d="M126 87 l1 -4 M138 82 l1 -4 M150 77 l1 -4" stroke="#ffe29a" stroke-width="3" stroke-linecap="round"/>
    <circle cx="110" cy="92" r="1.6" fill="#2b1608"/><circle cx="120" cy="88" r="1.6" fill="#2b1608"/>
    <circle cx="106" cy="98" r="8.5" fill="url(#kSkin)"/><circle cx="148" cy="84" r="8.5" fill="url(#kSkin)"/></g>
</g>
</svg>`;

  /* ---------------- Little Hanuman ---------------- */
  Art.hanuman = () => `
<svg viewBox="0 -14 200 300" class="god hanuman" role="img" aria-label="Little Hanuman smiling and waving">
<defs>
  <radialGradient id="hSkin" cx=".35" cy=".28" r=".85"><stop offset="0" stop-color="#ffd878"/><stop offset=".55" stop-color="#f2a52a"/><stop offset="1" stop-color="#c47612"/></radialGradient>
  <linearGradient id="hRed" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ef4a3a"/><stop offset="1" stop-color="#a21a1c"/></linearGradient>
  <linearGradient id="hGold" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff0b0"/><stop offset=".5" stop-color="#f1b93a"/><stop offset="1" stop-color="#b3720f"/></linearGradient>
  <radialGradient id="hFace" cx=".5" cy=".35" r=".8"><stop offset="0" stop-color="#fff0d2"/><stop offset="1" stop-color="#f6c98f"/></radialGradient>
</defs>
<ellipse cx="100" cy="274" rx="62" ry="9" fill="rgba(0,0,0,.4)"/>
<g class="bob b2">
  <g class="tail"><path d="M128 214 Q184 214 176 156 Q172 126 190 112" stroke="url(#hSkin)" stroke-width="13" fill="none" stroke-linecap="round"/><circle cx="190" cy="110" r="9" fill="#e08a1a"/></g>
  <rect x="76" y="222" width="20" height="44" rx="10" fill="url(#hSkin)"/><rect x="104" y="222" width="20" height="44" rx="10" fill="url(#hSkin)"/>
  <ellipse cx="86" cy="268" rx="15" ry="7" fill="#c47612"/><ellipse cx="114" cy="268" rx="15" ry="7" fill="#c47612"/>
  <ellipse cx="100" cy="142" rx="34" ry="38" fill="url(#hSkin)"/>
  <path d="M68 166 Q100 178 132 166 L142 236 Q100 250 58 236 Z" fill="url(#hRed)"/>
  <path d="M60 232 Q100 246 140 232" stroke="url(#hGold)" stroke-width="5" fill="none"/>
  <rect x="66" y="160" width="68" height="11" rx="5.5" fill="url(#hGold)"/>
  <path d="M76 120 Q100 150 124 120" stroke="#c0282c" stroke-width="7" stroke-dasharray="1 8.5" stroke-linecap="round" fill="none"/>
  <g><path d="M72 128 Q48 150 46 196" stroke="url(#hSkin)" stroke-width="15" stroke-linecap="round" fill="none"/>
    <rect x="42" y="150" width="9" height="86" rx="4.5" fill="#c9922a" transform="rotate(4 46 190)"/>
    <ellipse cx="40" cy="140" rx="17" ry="19" fill="url(#hGold)"/><circle cx="34" cy="132" r="3" fill="#b3720f"/><circle cx="46" cy="148" r="3" fill="#b3720f"/><circle cx="29" cy="146" r="3" fill="#b3720f"/>
    <circle cx="47" cy="196" r="9" fill="url(#hSkin)"/></g>
  <g class="wave"><path d="M128 128 Q154 118 158 84" stroke="url(#hSkin)" stroke-width="15" stroke-linecap="round" fill="none"/>
    <circle cx="158" cy="80" r="10.5" fill="url(#hSkin)"/><rect x="132" y="112" width="14" height="6" rx="3" fill="url(#hGold)" transform="rotate(-40 139 115)"/></g>
  <g class="headbob">
    <circle cx="52" cy="76" r="14" fill="#e59520"/><circle cx="52" cy="76" r="7.5" fill="#ffd9a8"/><circle cx="148" cy="76" r="14" fill="#e59520"/><circle cx="148" cy="76" r="7.5" fill="#ffd9a8"/>
    <circle cx="100" cy="74" r="45" fill="url(#hSkin)"/>
    <path d="M60 56 Q100 34 140 56 Q124 46 100 48 Q76 46 60 56Z" fill="#b8650d"/>
    <path d="M64 50 L72 20 L87 40 L100 10 L113 40 L128 20 L136 50 Q100 40 64 50Z" fill="url(#hGold)" stroke="#b3720f" stroke-width="1.2"/>
    <circle cx="100" cy="30" r="4.6" fill="#e03a3a"/><circle cx="76" cy="38" r="2.6" fill="#e03a3a"/><circle cx="124" cy="38" r="2.6" fill="#e03a3a"/>
    <ellipse cx="100" cy="92" rx="31" ry="23" fill="url(#hFace)"/>
    <path d="M100 52 L100 62" stroke="#e02020" stroke-width="4" stroke-linecap="round"/>
    <path d="M72 62 Q83 55 94 61 M106 61 Q117 55 128 62" stroke="#8d4a08" stroke-width="3.2" fill="none" stroke-linecap="round"/>
    <g class="eyes"><g class="eye" style="transform-origin:84px 76px"><ellipse cx="84" cy="76" rx="9" ry="10" fill="#fff"/><circle cx="85" cy="78" r="5.8" fill="#2a1408"/><circle cx="87" cy="75" r="2.2" fill="#fff"/></g>
    <g class="eye" style="transform-origin:116px 76px"><ellipse cx="116" cy="76" rx="9" ry="10" fill="#fff"/><circle cx="115" cy="78" r="5.8" fill="#2a1408"/><circle cx="117" cy="75" r="2.2" fill="#fff"/></g></g>
    <ellipse cx="95" cy="88" rx="1.8" ry="2.2" fill="#8a4a18"/><ellipse cx="105" cy="88" rx="1.8" ry="2.2" fill="#8a4a18"/>
    <path d="M84 98 Q100 114 116 98 Q100 104 84 98Z" fill="#fff" stroke="#6a2c10" stroke-width="2.2" stroke-linejoin="round"/>
    <circle cx="72" cy="92" r="6.5" fill="#ff8f7a" opacity=".5"/><circle cx="128" cy="92" r="6.5" fill="#ff8f7a" opacity=".5"/>
  </g>
</g>
</svg>`;

  /* ---------------- Little Ganesha ---------------- */
  Art.ganesha = () => `
<svg viewBox="0 -14 200 300" class="god ganesha" role="img" aria-label="Little Ganesha holding a modak">
<defs>
  <radialGradient id="gSkin" cx=".35" cy=".28" r=".85"><stop offset="0" stop-color="#ffcfa8"/><stop offset=".55" stop-color="#f0996a"/><stop offset="1" stop-color="#c9673a"/></radialGradient>
  <linearGradient id="gRed" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e83b52"/><stop offset="1" stop-color="#8f1530"/></linearGradient>
  <linearGradient id="gGold" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff0b0"/><stop offset=".5" stop-color="#f1b93a"/><stop offset="1" stop-color="#b3720f"/></linearGradient>
  <radialGradient id="gModak" cx=".4" cy=".3" r=".8"><stop offset="0" stop-color="#fff2b8"/><stop offset="1" stop-color="#e2a83a"/></radialGradient>
</defs>
<ellipse cx="100" cy="274" rx="66" ry="9" fill="rgba(0,0,0,.4)"/>
<g class="bob b3">
  <ellipse cx="78" cy="262" rx="20" ry="9" fill="#c9673a"/><ellipse cx="122" cy="262" rx="20" ry="9" fill="#c9673a"/>
  <ellipse cx="100" cy="176" rx="50" ry="54" fill="url(#gSkin)"/>
  <path d="M56 206 Q100 222 144 206 L150 252 Q100 268 50 252 Z" fill="url(#gRed)"/>
  <path d="M52 250 Q100 266 148 250" stroke="url(#gGold)" stroke-width="5" fill="none"/>
  <path d="M64 202 Q100 216 136 202" stroke="url(#gGold)" stroke-width="7" fill="none" stroke-linecap="round"/>
  <path d="M70 128 Q92 176 138 202" stroke="#fff0c8" stroke-width="3" fill="none" stroke-linecap="round" stroke-dasharray="5 3"/>
  <circle cx="100" cy="182" r="5" fill="#a64a22"/>
  <path d="M70 140 Q46 160 48 186" stroke="url(#gSkin)" stroke-width="16" stroke-linecap="round" fill="none"/>
  <g class="modak"><ellipse cx="46" cy="196" rx="24" ry="8" fill="url(#gGold)"/>
    <path d="M46 160 C34 172 32 190 46 193 C60 190 58 172 46 160Z" fill="url(#gModak)" stroke="#c18a22" stroke-width="1.2"/>
    <path d="M40 172 Q46 186 40 191 M52 172 Q46 186 52 191" stroke="#c18a22" stroke-width="1.2" fill="none" opacity=".7"/>
    <circle cx="46" cy="158" r="2.6" fill="#f6dc8a"/>
    <circle cx="47" cy="190" r="9.5" fill="url(#gSkin)"/></g>
  <g class="wave"><path d="M130 140 Q156 130 160 98" stroke="url(#gSkin)" stroke-width="16" stroke-linecap="round" fill="none"/>
    <circle cx="160" cy="94" r="11" fill="url(#gSkin)"/><rect x="132" y="122" width="15" height="6" rx="3" fill="url(#gGold)" transform="rotate(-40 139 125)"/></g>
  <g class="headbob">
    <ellipse cx="48" cy="82" rx="28" ry="32" fill="#e68a5c"/><ellipse cx="48" cy="82" rx="17" ry="22" fill="#ffb3a0"/>
    <ellipse cx="152" cy="82" rx="28" ry="32" fill="#e68a5c"/><ellipse cx="152" cy="82" rx="17" ry="22" fill="#ffb3a0"/>
    <circle cx="100" cy="80" r="45" fill="url(#gSkin)"/>
    <path d="M62 50 Q100 24 138 50 L134 58 Q100 40 66 58Z" fill="url(#gGold)"/>
    <path d="M80 44 L100 14 L120 44 Q100 36 80 44Z" fill="url(#gGold)" stroke="#b3720f" stroke-width="1.2"/>
    <circle cx="100" cy="36" r="5" fill="#e03a5a"/>
    <path d="M92 60 Q100 72 108 60" stroke="#e02020" stroke-width="3.4" fill="none" stroke-linecap="round"/>
    <g class="eyes"><g class="eye" style="transform-origin:83px 76px"><ellipse cx="83" cy="76" rx="8" ry="9.5" fill="#fff"/><circle cx="84" cy="78" r="5.2" fill="#2a1408"/><circle cx="86" cy="75" r="2" fill="#fff"/></g>
    <g class="eye" style="transform-origin:117px 76px"><ellipse cx="117" cy="76" rx="8" ry="9.5" fill="#fff"/><circle cx="116" cy="78" r="5.2" fill="#2a1408"/><circle cx="118" cy="75" r="2" fill="#fff"/></g></g>
    <g class="trunk"><path d="M100 84 Q90 112 106 126 Q122 134 130 116" stroke="url(#gSkin)" stroke-width="21" stroke-linecap="round" fill="none"/>
      <path d="M96 90 Q89 112 104 124" stroke="#ffd7b8" stroke-width="4" stroke-linecap="round" fill="none" opacity=".55"/></g>
    <path d="M114 104 Q126 108 124 122 Q116 118 112 108Z" fill="#fffaf0" stroke="#e5d6b8" stroke-width="1"/>
    <circle cx="70" cy="92" r="7" fill="#ff7f8f" opacity=".45"/><circle cx="132" cy="92" r="7" fill="#ff7f8f" opacity=".45"/>
  </g>
</g>
</svg>`;

  /* ---------------- Brass diya (unlit/lit via JS) ---------------- */
  Art.diya = () => `
<svg viewBox="0 0 260 230" class="diya-svg" role="img" aria-label="A brass diya">
<defs>
  <linearGradient id="brass" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffe9a6"/><stop offset=".35" stop-color="#e3a53a"/><stop offset=".7" stop-color="#9c6314"/><stop offset="1" stop-color="#5b3508"/></linearGradient>
  <radialGradient id="oil" cx=".5" cy=".4" r=".7"><stop offset="0" stop-color="#e8a32a"/><stop offset="1" stop-color="#7a4206"/></radialGradient>
  <radialGradient id="flameG" cx=".5" cy=".75" r=".75"><stop offset="0" stop-color="#fffbe0"/><stop offset=".35" stop-color="#ffd24a"/><stop offset=".75" stop-color="#ff8a14"/><stop offset="1" stop-color="#ff5a00" stop-opacity="0"/></radialGradient>
  <radialGradient id="glowG" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#ffc861" stop-opacity=".95"/><stop offset=".45" stop-color="#ff9a2a" stop-opacity=".35"/><stop offset="1" stop-color="#ff7a00" stop-opacity="0"/></radialGradient>
</defs>
<circle id="diyaGlow" cx="130" cy="96" r="120" fill="url(#glowG)" opacity="0"/>
<ellipse cx="130" cy="212" rx="70" ry="9" fill="rgba(0,0,0,.45)"/>
<path d="M104 204 Q130 190 156 204 L152 214 Q130 220 108 214Z" fill="url(#brass)"/>
<path d="M118 178 Q130 170 142 178 L146 200 Q130 206 114 200Z" fill="url(#brass)"/>
<path d="M30 112 C34 168 226 168 230 112 L248 100 C246 112 236 124 230 126 C210 176 50 176 30 126 C24 124 14 112 12 100Z" fill="url(#brass)"/>
<ellipse cx="130" cy="112" rx="100" ry="22" fill="#4a2a06"/>
<ellipse cx="130" cy="112" rx="100" ry="22" fill="none" stroke="url(#brass)" stroke-width="6"/>
<ellipse cx="130" cy="114" rx="86" ry="15" fill="url(#oil)"/>
<path d="M60 134 Q130 156 200 134" stroke="#fff3c0" stroke-opacity=".45" stroke-width="3" fill="none" stroke-linecap="round"/>
<path d="M62 150 q10 -6 18 0 q10 -6 18 0 q10 -6 18 0 q10 -6 18 0 q10 -6 18 0 q10 -6 18 0 q10 -6 18 0" stroke="#5b3508" stroke-opacity=".5" stroke-width="2.4" fill="none"/>
<rect x="127" y="94" width="6" height="22" rx="3" fill="#2a1a0a"/>
<g id="diyaFlame" style="transform-origin:130px 100px;transform:scale(0)"><path d="M130 100 C108 80 116 54 130 24 C144 54 152 80 130 100Z" fill="url(#flameG)"/><path d="M130 100 C122 90 124 76 130 64 C136 76 138 90 130 100Z" fill="#fffbe6" opacity=".9"/></g>
</svg>`;

  /* ---------------- Golden gift box ---------------- */
  Art.gift = () => `
<svg viewBox="0 0 260 260" class="gift-svg" role="img" aria-label="A golden gift box tied with a ribbon">
<defs>
  <linearGradient id="boxG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffe9a0"/><stop offset=".5" stop-color="#e8aa2c"/><stop offset="1" stop-color="#a8680c"/></linearGradient>
  <linearGradient id="lidG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff0b8"/><stop offset=".55" stop-color="#f0b53a"/><stop offset="1" stop-color="#b9730e"/></linearGradient>
  <linearGradient id="ribG" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#a8142e"/><stop offset=".5" stop-color="#e03352"/><stop offset="1" stop-color="#8e0f26"/></linearGradient>
  <radialGradient id="innerG" cx=".5" cy=".3" r=".8"><stop offset="0" stop-color="#fff6c8"/><stop offset="1" stop-color="#d4890f"/></radialGradient>
</defs>
<ellipse cx="130" cy="240" rx="92" ry="11" fill="rgba(0,0,0,.45)"/>
<g id="giftInside"><ellipse cx="130" cy="120" rx="76" ry="14" fill="url(#innerG)"/></g>
<g id="giftBody"><rect x="46" y="120" width="168" height="112" rx="7" fill="url(#boxG)"/>
  <rect x="46" y="120" width="168" height="14" fill="#000" opacity=".12"/>
  <rect id="ribV" x="116" y="120" width="28" height="112" fill="url(#ribG)" style="transform-origin:130px 176px"/>
  <path d="M60 148 h30 M60 170 h30 M170 148 h30 M170 170 h30" stroke="#fff3c0" stroke-opacity=".35" stroke-width="2"/></g>
<g id="giftLid" style="transform-origin:130px 110px"><rect x="36" y="84" width="188" height="42" rx="8" fill="url(#lidG)"/>
  <rect id="ribL" x="116" y="84" width="28" height="42" fill="url(#ribG)" style="transform-origin:130px 105px"/>
  <rect x="36" y="84" width="188" height="9" rx="4" fill="#fff" opacity=".28"/>
  <g id="bow"><ellipse id="bowL" cx="104" cy="74" rx="26" ry="15" fill="url(#ribG)" style="transform-origin:128px 82px"/>
    <ellipse id="bowR" cx="156" cy="74" rx="26" ry="15" fill="url(#ribG)" style="transform-origin:132px 82px"/>
    <circle id="bowK" cx="130" cy="82" r="11" fill="#c42040"/><circle cx="127" cy="79" r="3.5" fill="#fff" opacity=".35"/></g></g>
</svg>`;

  /* ---------------- Sweets ---------------- */
  Art.kajuKatli = () => {
    const d = (x, y, r, k) => `<g transform="translate(${x} ${y}) rotate(${r})">
      <path d="M0 -36 L50 0 L0 36 L-50 0Z" fill="url(#kkG)" filter="url(#kkShadow)"/>
      <path d="M0 -36 L50 0 L0 36 L-50 0Z" fill="url(#kkSheen)"/>
      <path d="M0 -36 L50 0 L-50 0Z" fill="#fff" opacity=".28"/>
      <path d="M0 36 L50 0 L0 -2 L-50 0Z" fill="#b08a4a" opacity=".16"/>
      <path d="M0 -36 L50 0 L0 36 L-50 0Z" fill="none" stroke="#c9a96a" stroke-opacity=".7" stroke-width="1.2"/></g>`;
    return `<svg viewBox="0 0 200 150" class="sw-svg" role="img" aria-label="Kaju Katli">
<defs>
  <linearGradient id="kkG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fffaf0"/><stop offset=".6" stop-color="#f5e6c4"/><stop offset="1" stop-color="#dcc38a"/></linearGradient>
  <linearGradient id="kkSheen" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".45" stop-color="#e8eef5" stop-opacity=".55"/><stop offset=".6" stop-color="#fff" stop-opacity="0"/></linearGradient>
  <filter id="kkShadow" x="-30%" y="-30%" width="160%" height="170%"><feDropShadow dx="0" dy="5" stdDeviation="4" flood-color="#000" flood-opacity=".45"/></filter>
</defs>
${d(60, 98, -8)}${d(128, 94, 10)}${d(96, 62, 0)}
<circle cx="96" cy="60" r="2.6" fill="#3f7a2e"/><rect x="52" y="94" width="10" height="3" rx="1.5" fill="#6aa34a" transform="rotate(-20 57 95)"/><rect x="124" y="90" width="10" height="3" rx="1.5" fill="#6aa34a" transform="rotate(15 129 91)"/>
</svg>`;
  };

  Art.gulabJamun = () => `<svg viewBox="0 0 200 150" class="sw-svg" role="img" aria-label="Gulab Jamun">
<defs>
  <radialGradient id="gjG" cx=".35" cy=".3" r=".8"><stop offset="0" stop-color="#b8602a"/><stop offset=".45" stop-color="#6e2a0c"/><stop offset="1" stop-color="#2c0f04"/></radialGradient>
  <linearGradient id="bowlG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffe9a6"/><stop offset=".4" stop-color="#d8962c"/><stop offset="1" stop-color="#6e4009"/></linearGradient>
  <radialGradient id="syrupG" cx=".5" cy=".4" r=".7"><stop offset="0" stop-color="#f6c35a"/><stop offset="1" stop-color="#9a5a0c"/></radialGradient>
</defs>
<ellipse cx="100" cy="132" rx="70" ry="9" fill="rgba(0,0,0,.4)"/>
<path d="M22 70 Q24 130 100 134 Q176 130 178 70Z" fill="url(#bowlG)"/>
<ellipse cx="100" cy="70" rx="78" ry="20" fill="url(#bowlG)"/>
<ellipse cx="100" cy="72" rx="68" ry="15" fill="url(#syrupG)"/>
<g>
  <ellipse cx="68" cy="66" rx="26" ry="24" fill="url(#gjG)"/><ellipse cx="60" cy="56" rx="9" ry="5" fill="#fff" opacity=".4" transform="rotate(-25 60 56)"/>
  <ellipse cx="132" cy="64" rx="26" ry="24" fill="url(#gjG)"/><ellipse cx="124" cy="54" rx="9" ry="5" fill="#fff" opacity=".4" transform="rotate(-25 124 54)"/>
  <ellipse cx="100" cy="52" rx="27" ry="25" fill="url(#gjG)"/><ellipse cx="92" cy="42" rx="10" ry="5.5" fill="#fff" opacity=".45" transform="rotate(-25 92 42)"/>
</g>
<path d="M60 74 Q70 82 82 76 M118 72 Q130 80 142 74" stroke="#f6c35a" stroke-opacity=".7" stroke-width="3" fill="none" stroke-linecap="round"/>
<g fill="#7bb04a"><rect x="86" y="38" width="9" height="2.6" rx="1.3" transform="rotate(25 90 39)"/><rect x="104" y="40" width="9" height="2.6" rx="1.3" transform="rotate(-30 108 41)"/><rect x="56" y="52" width="8" height="2.6" rx="1.3" transform="rotate(-20 60 53)"/><rect x="128" y="50" width="8" height="2.6" rx="1.3" transform="rotate(30 132 51)"/><rect x="96" y="30" width="7" height="2.4" rx="1.2" transform="rotate(70 99 31)"/></g>
<g fill="#e46a86" opacity=".85"><ellipse cx="78" cy="48" rx="3" ry="1.6" transform="rotate(30 78 48)"/><ellipse cx="146" cy="58" rx="3" ry="1.6"/></g>
</svg>`;

  Art.mysorePak = () => {
    const blk = (x, y, w, h, r) => `<g transform="translate(${x} ${y}) rotate(${r})">
      <rect x="0" y="0" width="${w}" height="${h}" rx="5" fill="url(#mpG)" filter="url(#mpShadow)"/>
      <rect x="0" y="0" width="${w}" height="${h}" rx="5" fill="#c46a06" filter="url(#mpPores)" opacity=".85"/>
      <rect x="0" y="0" width="${w}" height="9" rx="4" fill="#ffe08a" opacity=".5"/>
      <rect x="0" y="${h - 8}" width="${w}" height="8" rx="4" fill="#7a3e02" opacity=".3"/>
      <path d="M6 ${h * 0.4} H${w - 6}" stroke="#fff2b0" stroke-opacity=".28" stroke-width="2"/></g>`;
    return `<svg viewBox="0 0 200 150" class="sw-svg" role="img" aria-label="Mysore Pak">
<defs>
  <linearGradient id="mpG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f6c24a"/><stop offset=".55" stop-color="#e09a22"/><stop offset="1" stop-color="#b86f0e"/></linearGradient>
  <filter id="mpShadow" x="-20%" y="-20%" width="150%" height="170%"><feDropShadow dx="0" dy="5" stdDeviation="3.5" flood-color="#000" flood-opacity=".45"/></filter>
  <filter id="mpPores" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".85" numOctaves="2" seed="7" result="n"/><feColorMatrix in="n" type="matrix" values="0 0 0 0 .35  0 0 0 0 .16  0 0 0 0 .02  0 0 0 -9 4.6" result="spots"/><feComposite in="spots" in2="SourceAlpha" operator="in"/></filter>
</defs>
${blk(30, 78, 70, 48, -4)}${blk(98, 74, 70, 48, 5)}${blk(60, 28, 74, 50, 0)}
</svg>`;
  };

  /* ---------------- Garlands, bells, lights ---------------- */
  Art.garland = (w, sag, n, uid) => {
    let s = `<svg viewBox="0 0 ${w} ${sag + 60}" class="garland-svg" aria-hidden="true">`;
    s += `<path d="M0 8 Q${w / 2} ${sag * 2 - 8} ${w} 8" stroke="#6a3a08" stroke-width="2" fill="none"/>`;
    for (let i = 0; i <= n; i++) {
      const t = i / n;
      const x = t * w;
      const y = (1 - t) * (1 - t) * 8 + 2 * (1 - t) * t * (sag * 2 - 8) + t * t * 8;
      const o = i % 2 === 0;
      const c1 = o ? '#ff9a1a' : '#ffc21f', c2 = o ? '#e8590c' : '#f08c00';
      s += `<g transform="translate(${x.toFixed(1)} ${(y + 8).toFixed(1)})"><circle r="9" fill="${c2}"/><circle r="7" fill="${c1}"/><circle r="3.2" fill="#c2410c" opacity=".8"/><circle cx="-2" cy="-2.5" r="2" fill="#fff" opacity=".28"/></g>`;
    }
    return s + '</svg>';
  };

  Art.bell = () => `<svg viewBox="0 0 40 60" aria-hidden="true"><defs><linearGradient id="bellG" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#a8680c"/><stop offset=".4" stop-color="#ffe29a"/><stop offset="1" stop-color="#8a560a"/></linearGradient></defs>
<path d="M20 0 V14" stroke="#c9922a" stroke-width="2"/><path d="M8 40 Q8 14 20 14 Q32 14 32 40 Q34 44 36 46 H4 Q6 44 8 40Z" fill="url(#bellG)"/><circle cx="20" cy="50" r="4.4" fill="#d79a22"/></svg>`;

  /* ---------------- Cracker icons ---------------- */
  Art.icons = {
    sparkler: '<svg viewBox="0 0 48 48"><path d="M10 40 L30 14" stroke="#9aa3ad" stroke-width="2.6" stroke-linecap="round"/><g stroke="#ffd45a" stroke-width="1.6" stroke-linecap="round"><path d="M30 14 l6 -8 M30 14 l10 -2 M30 14 l8 6 M30 14 l-2 -10 M30 14 l-8 -4"/></g><circle cx="30" cy="14" r="2.6" fill="#fff6c8"/></svg>',
    flowerpot: '<svg viewBox="0 0 48 48"><path d="M14 44 L18 24 H30 L34 44Z" fill="#c4572a"/><path d="M16 36 H32" stroke="#ffd45a" stroke-width="2"/><g stroke="#ffcf4a" stroke-width="1.8" stroke-linecap="round"><path d="M24 22 V6 M24 22 L14 8 M24 22 L34 8 M24 22 L8 14 M24 22 L40 14"/></g></svg>',
    chakkar: '<svg viewBox="0 0 48 48"><circle cx="24" cy="24" r="16" fill="#8a3418"/><circle cx="24" cy="24" r="4" fill="#ffd45a"/><path d="M24 24 m0 -6 a6 6 0 1 1 -6 6 m-6 0 a12 12 0 1 1 12 12" stroke="#ffcf4a" stroke-width="2.2" fill="none" stroke-linecap="round"/></svg>',
    rocket: '<svg viewBox="0 0 48 48"><g transform="rotate(35 24 24)"><rect x="19" y="8" width="10" height="26" rx="2" fill="#d83a3a"/><path d="M19 8 L24 0 L29 8Z" fill="#f4d7a6"/><rect x="22.5" y="34" width="3" height="12" fill="#a8763a"/><path d="M19 30 H29" stroke="#ffd45a" stroke-width="2"/></g></svg>',
    shell: '<svg viewBox="0 0 48 48"><rect x="15" y="26" width="18" height="18" rx="3" fill="#2f5aa8"/><rect x="15" y="26" width="18" height="4" fill="#ffd45a"/><circle cx="24" cy="14" r="9" fill="#e0a21a"/><path d="M24 5 V1" stroke="#ffcf4a" stroke-width="2" stroke-linecap="round"/><circle cx="21" cy="11" r="2.6" fill="#fff" opacity=".4"/></svg>',
    comet: '<svg viewBox="0 0 48 48"><circle cx="24" cy="24" r="4" fill="#ff5a8a"/><circle cx="24" cy="24" r="10" fill="none" stroke="#4aa8ff" stroke-width="2.4" stroke-dasharray="2 4"/><circle cx="24" cy="24" r="17" fill="none" stroke="#ffd45a" stroke-width="2.4" stroke-dasharray="2 5"/></svg>',
    multishot: '<svg viewBox="0 0 48 48"><rect x="8" y="26" width="32" height="18" rx="3" fill="#7a2a8a"/><rect x="8" y="26" width="32" height="5" fill="#ffd45a"/><g stroke-width="2" stroke-linecap="round"><path d="M16 22 L12 8" stroke="#ff5a8a"/><path d="M24 22 V4" stroke="#4aa8ff"/><path d="M32 22 L36 8" stroke="#7bd96a"/></g><circle cx="12" cy="8" r="2.4" fill="#ff5a8a"/><circle cx="24" cy="4" r="2.4" fill="#4aa8ff"/><circle cx="36" cy="8" r="2.4" fill="#7bd96a"/></svg>'
  };
})();
