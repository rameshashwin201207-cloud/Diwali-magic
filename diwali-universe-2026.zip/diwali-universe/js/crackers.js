/* Diwali Universe 2026 — interactive virtual crackers.
   Seven crackers, each with its own look, motion, colours, duration and synthesised sound. */
(function () {
  'use strict';
  const U = window.U;
  const C = (U.Crackers = { items: [], active: false, cv: null, ctx: null, w: 0, h: 0, last: 0, running: false });
  const FW = () => U.FW;
  const SFX = () => U.Audio.fx;

  const DEFS = {
    sparkler:  { label: 'Sparkler',        note: 'Steady golden sparkle',     dur: 9 },
    flowerpot: { label: 'Flower pot',      note: 'Fountain of fire flowers',  dur: 7 },
    chakkar:   { label: 'Ground chakkar',  note: 'Spins and sprays sparks',   dur: 6.5 },
    rocket:    { label: 'Rocket',          note: 'Rises, then a bright burst', dur: 2.6 },
    shell:     { label: 'Aerial shell',    note: 'One huge sky burst',        dur: 3.4 },
    comet:     { label: 'Colour comet',    note: 'Three colour bursts in a row', dur: 4.5 },
    multishot: { label: 'Multi-shot cake', note: 'Fourteen shots, many colours', dur: 7.5 }
  };
  const ORDER = ['sparkler', 'flowerpot', 'chakkar', 'rocket', 'shell', 'comet', 'multishot'];

  C.init = function () {
    C.cv = U.$('#gd');
    C.resize();
    window.addEventListener('resize', C.resize);
    const tray = U.$('#crTray');
    tray.innerHTML = '';
    ORDER.forEach((k) => {
      const b = document.createElement('button');
      b.className = 'cr-card';
      b.type = 'button';
      b.dataset.k = k;
      b.setAttribute('aria-label', DEFS[k].label + '. ' + DEFS[k].note);
      b.innerHTML = '<span class="cr-ico">' + U.Art.icons[k === 'flowerpot' ? 'flowerpot' : k] + '</span><span class="cr-lab">' + DEFS[k].label + '</span>';
      b.addEventListener('click', () => C.place(k));
      tray.appendChild(b);
    });
    U.$('#brighter').addEventListener('click', C.grand);
  };

  C.resize = function () {
    const dpr = Math.min(window.devicePixelRatio || 1, 1.25);
    C.w = window.innerWidth; C.h = window.innerHeight;
    C.cv.width = Math.round(C.w * dpr); C.cv.height = Math.round(C.h * dpr);
    C.cv.style.width = C.w + 'px'; C.cv.style.height = C.h + 'px';
    C.ctx = C.cv.getContext('2d');
    C.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  };

  C.enter = function () {
    C.active = true;
    C.items.length = 0;
    C.resize();
    C.kick();
  };
  C.exit = function () {
    C.active = false;
    C.items.length = 0;
    if (C.ctx) C.ctx.clearRect(0, 0, C.w, C.h);
    clearTimeout(C._gt);
    const b = U.$('#brighter');
    b.disabled = false;
    b.textContent = 'MAKE THE SKY BRIGHTER!';
  };

  C.kick = function () {
    if (C.running || !C.active) return;
    C.running = true;
    C.last = 0;
    requestAnimationFrame(loop);
  };

  function groundSpot() {
    const top = C.h * 0.62, bot = C.h * 0.73;
    for (let tries = 0; tries < 12; tries++) {
      const x = U.rand(C.w * 0.12, C.w * 0.88);
      if (C.items.every((it) => Math.abs(it.x - x) > 46)) return { x, y: U.rand(top, bot) };
    }
    return { x: U.rand(C.w * 0.12, C.w * 0.88), y: U.rand(top, bot) };
  }

  C.place = function (kind) {
    if (!C.active) return;
    if (U.Audio.ctx && U.Audio.ctx.state === 'suspended') U.Audio.ctx.resume();
    if (C.items.filter((i) => i.state !== 'done').length >= 6) {
      U.toast('Let a few crackers finish first.');
      return;
    }
    const sp = groundSpot();
    const depth = (sp.y - C.h * 0.62) / (C.h * 0.11);
    const it = { kind, x: sp.x, y: sp.y, s: (U.isMobile() ? 0.8 : 1) * (0.85 + depth * 0.25), t: 0, state: 'fuse', fuse: 0.85, dur: DEFS[kind].dur, rot: 0, fade: 1 };
    C.items.push(it);
    if (SFX()) SFX().crackle(5, 0.8, (it.x / C.w) * 2 - 1, 0);
    C.kick();
  };

  C.grand = function () {
    const b = U.$('#brighter');
    if (b.disabled) return;
    b.disabled = true;
    const total = FW().show('grand');
    let left = Math.ceil((total + 2500) / 1000);
    b.textContent = 'The sky is glowing…';
    FW().later(() => {
      if (C.active) {
        b.disabled = false;
        b.textContent = 'MAKE THE SKY BRIGHTER!';
      }
    }, total + 2500);
  };

  function ignite(it) {
    const pan = (it.x / C.w) * 2 - 1;
    const F = FW(), S = SFX();
    it.state = 'burn';
    it.t = 0;
    switch (it.kind) {
      case 'sparkler':
        if (S) S.hiss(it.dur, 6200, pan, 0.1);
        break;
      case 'flowerpot':
        if (S) { S.whoosh(); S.hiss(it.dur, 3200, pan, 0.17); }
        break;
      case 'chakkar':
        if (S) S.whirr(it.dur, pan);
        break;
      case 'rocket':
        it.state = 'done';
        F.rocket({ x: it.x, y0: it.y - 40 * it.s, ty: U.rand(C.h * 0.12, C.h * 0.34), type: U.pick(['peony', 'chrysanthemum', 'double']), pal: U.pick(['red', 'pink', 'blue', 'green', 'multi']), scale: 1.15 });
        break;
      case 'shell':
        it.state = 'done';
        if (S) S.pop(pan);
        F.rocket({ x: it.x, y0: it.y - 40 * it.s, ty: U.rand(C.h * 0.1, C.h * 0.24), type: U.pick(['willow', 'crackle']), pal: U.pick(['gold', 'multi']), scale: 1.75, silent: true });
        if (S) F.later(() => S.whistle(0.8, pan), 80);
        break;
      case 'comet': {
        it.state = 'done';
        const x = it.x;
        const seq = [
          { d: 0, type: 'ring', pal: 'blue', ty: 0.36, sc: 1.1 },
          { d: 650, type: 'double', pal: 'pink', ty: 0.27, sc: 1.25 },
          { d: 1300, type: 'chrysanthemum', pal: 'multi', ty: 0.18, sc: 1.45 }
        ];
        seq.forEach((q) => F.later(() => F.rocket({ x: x + U.rand(-30, 30), y0: it.y - 40 * it.s, ty: C.h * q.ty, type: q.type, pal: q.pal, scale: q.sc }), q.d));
        break;
      }
      case 'multishot':
        it.shots = 14;
        it.next = 0;
        break;
    }
  }

  function emit(it, dt) {
    const F = FW();
    const k = it.t / it.dur;
    const x = it.x, y = it.y, s = it.s;
    switch (it.kind) {
      case 'sparkler': {
        const tipY = y - 82 * s + k * 38 * s;
        it.tipY = tipY;
        const n = Math.round(90 * dt * (k > 0.93 ? 0.2 : 1));
        for (let i = 0; i < n; i++) {
          const a = U.rand(0, Math.PI * 2), v = U.rand(40, 190) * s;
          F.spark({ x, y: tipY, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 20, life: U.rand(0.3, 0.7), h: U.rand(38, 56), s: 100, l: U.rand(70, 90), size: 1.3, g: 260, drag: 0.93, twinkle: Math.random() < 0.3 });
        }
        break;
      }
      case 'flowerpot': {
        const env = k < 0.2 ? k / 0.2 : Math.max(0.15, 1 - (k - 0.2) / 0.8);
        const topY = y - 46 * s;
        const n = Math.round(170 * dt * (0.4 + env));
        const hue = k < 0.4 ? 44 : k < 0.7 ? 24 : 330;
        for (let i = 0; i < n; i++) {
          const a = -Math.PI / 2 + U.rand(-0.4, 0.4), v = U.rand(220, 420) * s * (0.55 + env * 0.6);
          const col = Math.random() < 0.2 ? U.pick([140, 200, 300]) : hue + U.rand(-8, 8);
          F.spark({ x: x + U.rand(-5, 5), y: topY, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: U.rand(0.7, 1.3), h: col, s: 100, l: U.rand(58, 74), size: 1.8, g: 420, drag: 0.975, twinkle: Math.random() < 0.2 });
        }
        break;
      }
      case 'chakkar': {
        const env = Math.pow(Math.sin(Math.PI * Math.min(1, k)), 0.6);
        it.rot += (4 + 22 * env) * dt;
        const n = Math.round(190 * dt * (0.3 + env));
        const R = 24 * s;
        for (let i = 0; i < n; i++) {
          const a = it.rot + U.rand(-0.25, 0.25);
          const px = x + Math.cos(a) * R, py = y + Math.sin(a) * R * 0.38;
          const tx = -Math.sin(a), ty = Math.cos(a);
          const v = U.rand(120, 240) * s;
          F.spark({ x: px, y: py, vx: (tx * 0.9 + Math.cos(a) * 0.5) * v, vy: (ty * 0.9 * 0.5 + Math.sin(a) * 0.2) * v - U.rand(0, 70), life: U.rand(0.35, 0.8), h: U.pick([42, 34, 28, 120, 48]), s: 100, l: U.rand(62, 82), size: 1.6, g: 330, drag: 0.94 });
        }
        break;
      }
      case 'multishot': {
        const boxY = y - 30 * s;
        if (it.shots > 0 && it.t >= it.next) {
          it.shots--;
          it.next = it.t + 0.5;
          const pal = U.pick(['red', 'blue', 'green', 'purple', 'pink', 'gold', 'orange', 'multi']);
          if (SFX()) SFX().pop((x / C.w) * 2 - 1);
          F.rocket({ x: x + U.rand(-26, 26), y0: boxY, ty: U.rand(C.h * 0.1, C.h * 0.42), type: U.pick(['peony', 'crackle', 'ring', 'chrysanthemum']), pal, scale: U.rand(0.6, 0.95), silent: false });
          for (let i = 0; i < 10; i++) F.spark({ x, y: boxY, vx: U.rand(-90, 90), vy: U.rand(-200, -60), life: U.rand(0.2, 0.45), h: 40, s: 100, l: 75, size: 1.5, g: 300 });
        }
        break;
      }
    }
  }

  /* ---------- drawing ---------- */
  function drawItem(c, it) {
    const x = it.x, y = it.y, s = it.s;
    c.globalAlpha = it.fade;
    // shadow
    c.fillStyle = 'rgba(0,0,0,.4)';
    c.beginPath(); c.ellipse(x, y + 3 * s, 22 * s, 6 * s, 0, 0, Math.PI * 2); c.fill();
    switch (it.kind) {
      case 'sparkler': {
        const k = it.state === 'burn' ? it.t / it.dur : 0;
        c.lineCap = 'round';
        c.strokeStyle = '#a7afb9'; c.lineWidth = 2.4 * s;
        c.beginPath(); c.moveTo(x, y); c.lineTo(x, y - 44 * s); c.stroke();
        c.strokeStyle = '#4e535b'; c.lineWidth = 4.2 * s;
        c.beginPath(); c.moveTo(x, y - 44 * s); c.lineTo(x, y - 82 * s + k * 38 * s); c.stroke();
        break;
      }
      case 'flowerpot': {
        const g = c.createLinearGradient(x - 18 * s, 0, x + 18 * s, 0);
        g.addColorStop(0, '#8e3a1c'); g.addColorStop(0.5, '#d8683a'); g.addColorStop(1, '#8e3a1c');
        c.fillStyle = g;
        c.beginPath(); c.moveTo(x - 13 * s, y - 46 * s); c.lineTo(x + 13 * s, y - 46 * s); c.lineTo(x + 18 * s, y); c.lineTo(x - 18 * s, y); c.closePath(); c.fill();
        c.fillStyle = '#ffd45a'; c.fillRect(x - 15 * s, y - 28 * s, 30 * s, 4 * s);
        c.fillStyle = '#2a1408'; c.beginPath(); c.ellipse(x, y - 46 * s, 13 * s, 3.5 * s, 0, 0, Math.PI * 2); c.fill();
        break;
      }
      case 'chakkar': {
        c.save();
        c.translate(x, y - 3 * s);
        c.scale(1, 0.38);
        c.rotate(it.rot);
        const g = c.createRadialGradient(0, 0, 2, 0, 0, 25 * s);
        g.addColorStop(0, '#ffd45a'); g.addColorStop(0.25, '#c4562a'); g.addColorStop(1, '#6b2210');
        c.fillStyle = g;
        c.beginPath(); c.arc(0, 0, 25 * s, 0, Math.PI * 2); c.fill();
        c.strokeStyle = 'rgba(255,220,120,.7)'; c.lineWidth = 2 * s;
        c.beginPath();
        for (let a = 0; a < 12; a += 0.2) c.lineTo(Math.cos(a) * (3 + a * 1.8) * s, Math.sin(a) * (3 + a * 1.8) * s);
        c.stroke();
        c.restore();
        break;
      }
      case 'multishot': {
        const w = 44 * s, h = 30 * s;
        const g = c.createLinearGradient(0, y - h, 0, y);
        g.addColorStop(0, '#9b3bb0'); g.addColorStop(1, '#52206a');
        c.fillStyle = g; c.fillRect(x - w / 2, y - h, w, h);
        c.fillStyle = '#ffd45a'; c.fillRect(x - w / 2, y - h, w, 6 * s);
        c.fillStyle = '#ffffff'; c.globalAlpha = it.fade * 0.25; c.fillRect(x - w / 2, y - h, 6 * s, h); c.globalAlpha = it.fade;
        break;
      }
    }
    // fuse glow
    if (it.state === 'fuse') {
      const fy = it.kind === 'sparkler' ? y - 82 * s : it.kind === 'chakkar' ? y - 6 * s : it.kind === 'multishot' ? y - 30 * s : y - 46 * s;
      c.globalCompositeOperation = 'lighter';
      const r = (5 + Math.random() * 4) * s;
      const g = c.createRadialGradient(x, fy, 0, x, fy, r * 2);
      g.addColorStop(0, 'rgba(255,240,170,1)'); g.addColorStop(1, 'rgba(255,140,30,0)');
      c.fillStyle = g; c.fillRect(x - r * 2, fy - r * 2, r * 4, r * 4);
      c.globalCompositeOperation = 'source-over';
    }
    // burn glow on the ground
    if (it.state === 'burn') {
      c.globalCompositeOperation = 'lighter';
      const gy = it.kind === 'sparkler' ? (it.tipY || y - 70 * s) : y - 20 * s;
      const r = (it.kind === 'sparkler' ? 40 : 70) * s;
      const g = c.createRadialGradient(x, gy, 0, x, gy, r);
      g.addColorStop(0, 'rgba(255,214,120,.5)'); g.addColorStop(1, 'rgba(255,140,30,0)');
      c.fillStyle = g; c.fillRect(x - r, gy - r, r * 2, r * 2);
      c.globalCompositeOperation = 'source-over';
    }
    c.globalAlpha = 1;
  }

  function loop(now) {
    if (!C.active || document.hidden) { C.running = false; return; }
    const dt = C.last ? Math.min(0.05, (now - C.last) / 1000) : 0.016;
    C.last = now;
    const c = C.ctx;
    c.clearRect(0, 0, C.w, C.h);
    for (let i = C.items.length - 1; i >= 0; i--) {
      const it = C.items[i];
      if (it.state === 'fuse') {
        it.fuse -= dt;
        if (Math.random() < 0.5) FW().spark({ x: it.x, y: it.y - 40 * it.s, vx: U.rand(-40, 40), vy: U.rand(-80, -10), life: 0.3, h: 40, s: 100, l: 80, size: 1.2, g: 200 });
        if (it.fuse <= 0) ignite(it);
      } else if (it.state === 'burn') {
        it.t += dt;
        emit(it, dt);
        if (it.t >= it.dur) it.state = 'fading';
      } else if (it.state === 'fading') {
        it.fade -= dt * 1.2;
        if (it.fade <= 0) it.state = 'done';
      }
      if (it.state === 'done') { C.items.splice(i, 1); continue; }
      drawItem(c, it);
    }
    if (C.items.length) requestAnimationFrame(loop);
    else C.running = false;
  }
})();
