/* Diwali Universe 2026 — shared helpers and per-visit state (kept in memory only). */
(function () {
  'use strict';
  const U = (window.U = window.U || {});

  U.$ = (s, r) => (r || document).querySelector(s);
  U.$$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  U.rand = (a, b) => a + Math.random() * (b - a);
  U.randi = (a, b) => Math.floor(U.rand(a, b + 1));
  U.pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
  U.clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  U.lerp = (a, b, t) => a + (b - a) * t;
  U.isMobile = () => Math.min(window.innerWidth, window.innerHeight) < 700 || /Android|iPhone|iPad/i.test(navigator.userAgent);

  /* Visitor info lives only in this JS object for the current page visit.
     Nothing is written to storage, cookies or a server, so one visitor can never see another's data. */
  U.visitor = { name: '', gender: '', relation: '', isMalar: false };

  /* "Malar Meena" check: case-insensitive, ignores spaces, dots and punctuation, so
     "malar meena", "MALARMEENA" and "Malar  Meena" all match, but "Malar Meenakshi" does not. */
  U.normName = (s) => String(s || '').toLowerCase().normalize('NFKD').replace(/[^a-z]/g, '');
  U.isMalarMeena = (s) => U.normName(s) === 'malarmeena';

  /* Display-safe name: trim, collapse spaces, title-case each word. */
  U.cleanName = (s) => {
    let n = String(s || '').replace(/\s+/g, ' ').trim().slice(0, 32);
    // all-lowercase or ALL-CAPS input is tidied to Title Case; mixed case is kept as typed
    if (n === n.toLowerCase() || n === n.toUpperCase()) n = n.toLowerCase();
    return n.replace(/(^|[\s\-'])(\p{L})/gu, (m, a, b) => a + b.toUpperCase());
  };

  U.reducedMotion = (() => {
    const mq = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;
    return { on: !!(mq && mq.matches) };
  })();
  U.rm = () => U.reducedMotion.on;
  U.dur = (ms) => (U.rm() ? ms * 0.5 : ms);

  /* Cancellable timeline so a skipped / left scene stops its pending steps. */
  U.Timeline = function () {
    let dead = false;
    const timers = new Set();
    this.wait = (ms) =>
      new Promise((res, rej) => {
        if (dead) return rej(new Error('cancelled'));
        const id = setTimeout(() => {
          timers.delete(id);
          res();
        }, ms);
        timers.add(id);
        timers.rej = timers.rej || new Map();
        timers.rej.set(id, rej);
      });
    this.cancel = () => {
      dead = true;
      timers.forEach((id) => {
        clearTimeout(id);
        const r = timers.rej && timers.rej.get(id);
        if (r) r(new Error('cancelled'));
      });
      timers.clear();
    };
    this.alive = () => !dead;
  };
  U.sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  U.toast = (msg, ms) => {
    const t = U.$('#toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(U.toast._t);
    U.toast._t = setTimeout(() => t.classList.remove('show'), ms || 3200);
  };

  /* ---------- Diwali date logic (Asia/Kolkata) ---------- */
  U.DIWALI_START = Date.parse('2026-11-08T00:00:00+05:30');
  U.DIWALI_END = Date.parse('2026-11-09T00:00:00+05:30');
  U.diwaliState = (now) => {
    now = now == null ? Date.now() : now;
    if (now < U.DIWALI_START) {
      let s = Math.floor((U.DIWALI_START - now) / 1000);
      const days = Math.floor(s / 86400);
      s -= days * 86400;
      const hours = Math.floor(s / 3600);
      s -= hours * 3600;
      const minutes = Math.floor(s / 60);
      const seconds = s - minutes * 60;
      return { phase: 'before', days, hours, minutes, seconds };
    }
    if (now < U.DIWALI_END) return { phase: 'today', days: 0, hours: 0, minutes: 0, seconds: 0 };
    return { phase: 'after', days: 0, hours: 0, minutes: 0, seconds: 0 };
  };

  /* ---------- Personalised copy ---------- */
  U.greetingFor = (v) => {
    const sib = v.gender === 'female' ? ' Sis' : v.gender === 'male' ? ' Bro' : '';
    const map = {
      father: 'You are my strength, my inspiration and my everything, Dad.',
      mother: 'You are the most beautiful blessing in my life, Mom.',
      sibling: 'Life becomes more beautiful because I have you' + (sib ? ',' + sib : '') + '.',
      family: 'You are more than a family member; you are a precious part of my heart.',
      friend: 'You are more than a friend; you are my family.',
      special: 'Some people make every light feel warmer, and you are one of them. Wishing you a Diwali as lovely as you are.',
      other: 'Wishing you and everyone you love a Diwali full of warmth, light and joy.'
    };
    return map[v.relation] || map.other;
  };

  U.giftBlessing = (v) => {
    const t = {
      father: ['Dad, may every lamp you light return to you as health, peace and pride.', 'அப்பா, உங்கள் அன்பும் வழிகாட்டுதலும் என் வாழ்வின் ஒளி. இனிய தீபாவளி நல்வாழ்த்துகள்!'],
      mother: ['Mom, may your kindness come back to you in a thousand glowing lights.', 'அம்மா, உங்கள் அன்பே என் வாழ்வின் மிகப்பெரிய ஆசீர்வாதம். இனிய தீபாவளி நல்வாழ்த்துகள்!'],
      sibling: ['May our home, our laughter and our little fights always stay full of light.', 'உன்னுடன் இருக்கும் ஒவ்வொரு நாளும் தீபாவளிதான். இனிய தீபாவளி நல்வாழ்த்துகள்!'],
      family: ['May your home glow with love, good health and good news all year.', 'உங்கள் இல்லம் எப்போதும் ஒளியால் நிறைந்திருக்கட்டும். இனிய தீபாவளி நல்வாழ்த்துகள்!'],
      friend: ['May your year sparkle with big laughs, small joys and dreams that come true.', 'என் அன்பு நட்பே, உன் வாழ்வில் மகிழ்ச்சி பொங்கட்டும். இனிய தீபாவளி நல்வாழ்த்துகள்!'],
      special: ['May happiness find you in every small moment, and may your lamps always burn bright.', 'உங்கள் வாழ்வில் ஒளியும் மகிழ்ச்சியும் என்றும் நிலைக்கட்டும். இனிய தீபாவளி நல்வாழ்த்துகள்!'],
      other: ['May this Diwali bring light to every corner of your life.', 'உங்கள் வாழ்வில் ஒளியும் மகிழ்ச்சியும் என்றும் நிலைக்கட்டும். இனிய தீபாவளி நல்வாழ்த்துகள்!']
    };
    if (v.isMalar) return ['May your sky always have a moon, a few stars and a little golden light of your own.', 'என் நிலவுக்கு இனிய தீபாவளி நல்வாழ்த்துகள்!'];
    return t[v.relation] || t.other;
  };

  U.MALAR_EN = 'You are more than a person; you are my angel, my dear famous person.';
  U.MALAR_TA = 'என் நிலவுக்கு இனிய தீபாவளி நல்வாழ்த்துகள்!';
})();
