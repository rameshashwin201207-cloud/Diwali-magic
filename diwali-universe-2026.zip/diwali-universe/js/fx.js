/* Diwali Universe 2026 — canvas effects: night sky, fireworks, emitters, particle text. */
(function () {
  'use strict';
  const U = window.U;
  const TAU = Math.PI * 2;

  function fit(cv, maxDpr) {
    const dpr = Math.min(window.devicePixelRatio || 1, maxDpr);
    const w = window.innerWidth, h = window.innerHeight;
    cv.width = Math.round(w * dpr);
    cv.height = Math.round(h * dpr);
    cv.style.width = w + 'px';
    cv.style.height = h + 'px';
    const ctx = cv.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    return { ctx, w, h, dpr };
  }

  /* ======================= SKY ======================= */
  const Sky = (U.Sky = {
    cv: null, ctx: null, w: 0, h: 0,
    stars: [], motes: [],
    alpha: 0, target: 0, moteAlpha: 0, moteTarget: 0,
    last: 0, running: false
  });

  Sky.init = function () {
    Sky.cv = U.$('#sky');
    Sky.resize();
    const nStars = U.isMobile() ? 110 : 190;
    for (let i = 0; i < nStars; i++) {
      Sky.stars.push({ x: Math.random(), y: Math.random() * 0.85, r: U.rand(0.4, 1.6), tw: U.rand(0, TAU), sp: U.rand(0.6, 2.2) });
    }
    const nMotes = U.isMobile() ? 26 : 46;
    for (let i = 0; i < nMotes; i++) Sky.motes.push(newMote(true));
    window.addEventListener('resize', Sky.resize);
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) { Sky.last = 0; kick(); }
    });
    kick();
  };
  function newMote(anywhere) {
    return { x: Math.random(), y: anywhere ? Math.random() : 1.05, r: U.rand(1, 2.8), vy: U.rand(0.008, 0.03), ph: U.rand(0, TAU), sw: U.rand(0.01, 0.03) };
  }
  Sky.resize = function () {
    const f = fit(Sky.cv, 1.5);
    Sky.ctx = f.ctx; Sky.w = f.w; Sky.h = f.h;
  };
  Sky.setStars = (a) => (Sky.target = a);
  Sky.setMotes = (a) => (Sky.moteTarget = a);
  function kick() {
    if (Sky.running) return;
    Sky.running = true;
    requestAnimationFrame(skyFrame);
  }
  function skyFrame(now) {
    if (document.hidden) { Sky.running = false; return; }
    const dt = Sky.last ? Math.min(0.1, (now - Sky.last) / 1000) : 0.016;
    Sky.last = now;
    Sky.alpha += (Sky.target - Sky.alpha) * Math.min(1, dt * 0.9);
    Sky.moteAlpha += (Sky.moteTarget - Sky.moteAlpha) * Math.min(1, dt * 0.8);
    const c = Sky.ctx, w = Sky.w, h = Sky.h, t = now / 1000;
    c.clearRect(0, 0, w, h);
    if (Sky.alpha > 0.01) {
      for (const s of Sky.stars) {
        const a = Sky.alpha * (0.45 + 0.55 * Math.sin(t * s.sp + s.tw));
        c.globalAlpha = Math.max(0, a);
        c.fillStyle = '#fff4d8';
        c.beginPath();
        c.arc(s.x * w, s.y * h, s.r, 0, TAU);
        c.fill();
      }
    }
    if (Sky.moteAlpha > 0.01) {
      c.globalCompositeOperation = 'lighter';
      for (const m of Sky.motes) {
        m.y -= m.vy * dt * (U.rm() ? 0.4 : 1);
        if (m.y < -0.05) Object.assign(m, newMote(false));
        const x = (m.x + Math.sin(t * 0.4 + m.ph) * m.sw) * w;
        const y = m.y * h;
        const a = Sky.moteAlpha * (0.35 + 0.35 * Math.sin(t * 1.3 + m.ph));
        const g = c.createRadialGradient(x, y, 0, x, y, m.r * 5);
        g.addColorStop(0, 'rgba(255,214,120,' + a + ')');
        g.addColorStop(1, 'rgba(255,170,60,0)');
        c.globalAlpha = 1;
        c.fillStyle = g;
        c.fillRect(x - m.r * 5, y - m.r * 5, m.r * 10, m.r * 10);
      }
      c.globalCompositeOperation = 'source-over';
    }
    c.globalAlpha = 1;
    requestAnimationFrame(skyFrame);
  }

  /* ======================= FIREWORKS ======================= */
  const FW = (U.FW = {
    cv: null, ctx: null, w: 0, h: 0,
    parts: [], rockets: [], emitters: [], timers: [],
    running: false, last: 0, scale: 1
  });

  const MAX = () => (U.isMobile() ? 520 : 1000);

  const PALETTES = {
    gold: [[40, 100, 62], [46, 100, 70], [34, 100, 58]],
    red: [[2, 95, 58], [350, 90, 62], [14, 100, 60]],
    blue: [[210, 95, 62], [195, 100, 62], [225, 90, 70]],
    green: [[130, 80, 55], [150, 85, 52], [95, 80, 56]],
    purple: [[280, 85, 66], [300, 80, 68], [262, 85, 68]],
    pink: [[325, 95, 68], [340, 95, 70], [305, 85, 70]],
    white: [[48, 40, 92], [200, 30, 94], [40, 70, 86]],
    orange: [[24, 100, 58], [32, 100, 56], [14, 100, 58]]
  };
  FW.PALETTES = PALETTES;
  const PAL_KEYS = ['gold', 'red', 'blue', 'green', 'purple', 'pink', 'white', 'orange'];

  FW.init = function () {
    FW.cv = U.$('#fw');
    FW.resize();
    window.addEventListener('resize', FW.resize);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) FW.last = 0; });
  };
  FW.resize = function () {
    const f = fit(FW.cv, U.isMobile() ? 1.25 : 1.5);
    FW.ctx = f.ctx; FW.w = f.w; FW.h = f.h;
  };

  function ensure() {
    if (FW.running) return;
    FW.running = true;
    FW.last = 0;
    requestAnimationFrame(frame);
  }
  FW.ensure = ensure;

  /* low-level spark: used by emitters and bursts */
  FW.spark = function (o) {
    if (FW.parts.length > MAX()) return;
    FW.parts.push({
      x: o.x, y: o.y, px: o.x, py: o.y, vx: o.vx, vy: o.vy,
      g: o.g == null ? 140 : o.g, drag: o.drag == null ? 0.96 : o.drag,
      life: o.life, max: o.life, h: o.h, s: o.s, l: o.l,
      size: o.size || 1.6, twinkle: !!o.twinkle, child: o.child || 0, sub: o.sub || 0
    });
    ensure();
  };

  function palColor(pal) {
    const p = PALETTES[pal] || PALETTES.gold;
    return U.pick(p);
  }

  /* Burst types. R is the target radius in px. */
  FW.burst = function (x, y, type, pal, scale) {
    scale = (scale || 1) * (U.rm() ? 0.55 : 1);
    const base = Math.min(FW.w, FW.h) * (U.isMobile() ? 0.2 : 0.17) * scale;
    const K = 2.5; // v0 = distance * K for drag 0.96 @60fps
    const mobile = U.isMobile() ? 0.7 : 1;
    const second = pal === 'multi' ? U.pick(PAL_KEYS) : null;
    const col = () => (pal === 'multi' ? palColor(U.pick(PAL_KEYS)) : palColor(pal));
    let n;
    switch (type) {
      case 'ring': {
        n = Math.floor(60 * scale * mobile) + 20;
        const tilt = U.rand(0.35, 1), rot = U.rand(0, TAU), c = col();
        for (let i = 0; i < n; i++) {
          const a = (i / n) * TAU;
          const vx = Math.cos(a) * base * K, vy = Math.sin(a) * base * K * tilt;
          const cs = Math.cos(rot), sn = Math.sin(rot);
          FW.spark({ x, y, vx: vx * cs - vy * sn, vy: vx * sn + vy * cs, life: U.rand(1.1, 1.5), h: c[0], s: c[1], l: c[2], size: 2, g: 60 });
        }
        break;
      }
      case 'willow': {
        n = Math.floor(70 * scale * mobile) + 20;
        const c = col();
        for (let i = 0; i < n; i++) {
          const a = U.rand(0, TAU), v = base * K * U.rand(0.5, 1) * 0.95;
          FW.spark({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: U.rand(2.4, 3.4), h: c[0], s: c[1], l: c[2], size: 1.8, g: 120, drag: 0.972 });
        }
        break;
      }
      case 'crackle': {
        n = Math.floor(80 * scale * mobile) + 20;
        const c = col();
        for (let i = 0; i < n; i++) {
          const a = U.rand(0, TAU), v = base * K * U.rand(0.7, 1);
          FW.spark({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: U.rand(1.4, 2.1), h: c[0], s: c[1], l: c[2], size: 1.6, twinkle: true });
        }
        break;
      }
      case 'star': {
        n = Math.floor(110 * scale * mobile) + 30;
        const c = col(), rot = -Math.PI / 2;
        for (let i = 0; i < n; i++) {
          const a = U.rand(0, TAU);
          const f = 0.42 + 0.58 * Math.pow(Math.abs(Math.cos(2.5 * (a - rot))), 2.4);
          const v = base * K * f * U.rand(0.92, 1);
          FW.spark({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: U.rand(1.5, 2), h: c[0], s: c[1], l: c[2], size: 2, g: 50, drag: 0.955 });
        }
        break;
      }
      case 'double': {
        const c1 = col(), c2 = pal === 'multi' ? palColor(second) : palColor('white');
        n = Math.floor(60 * scale * mobile) + 20;
        for (let i = 0; i < n; i++) {
          const a = U.rand(0, TAU), v = base * K * U.rand(0.85, 1);
          FW.spark({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: U.rand(1.4, 1.9), h: c1[0], s: c1[1], l: c1[2], size: 1.9 });
        }
        for (let i = 0; i < n * 0.6; i++) {
          const a = (i / (n * 0.6)) * TAU, v = base * K * 0.5;
          FW.spark({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: U.rand(1.1, 1.4), h: c2[0], s: c2[1], l: c2[2], size: 1.7 });
        }
        break;
      }
      case 'chrysanthemum': {
        n = Math.floor(48 * scale * mobile) + 14;
        const c = col();
        for (let i = 0; i < n; i++) {
          const a = U.rand(0, TAU), v = base * K * U.rand(0.8, 1);
          FW.spark({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: U.rand(1.4, 1.9), h: c[0], s: c[1], l: c[2], size: 2.2, child: 1 });
        }
        break;
      }
      default: { // peony
        n = Math.floor(80 * scale * mobile) + 24;
        const c = col();
        for (let i = 0; i < n; i++) {
          const a = U.rand(0, TAU), v = base * K * U.rand(0.8, 1);
          FW.spark({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: U.rand(1.3, 1.8), h: c[0], s: c[1], l: c[2], size: 2 });
        }
      }
    }
    // soft flash
    FW.flashes = FW.flashes || [];
    FW.flashes.push({ x, y, r: base * 1.1, a: 0.55, h: palColor(pal === 'multi' ? 'gold' : pal)[0] });
    ensure();
  };

  /* Rocket: rises with a spark trail, then explodes. opts: {x, ty, type, pal, scale, size, silent, onBurst} */
  FW.rocket = function (o) {
    o = o || {};
    const x0 = o.x != null ? o.x : U.rand(FW.w * 0.12, FW.w * 0.88);
    const y0 = o.y0 != null ? o.y0 : FW.h + 10;
    const ty = o.ty != null ? o.ty : U.rand(FW.h * 0.12, FW.h * 0.45);
    const rise = Math.max(0.7, (y0 - ty) / FW.h * 1.25);
    const vy = -(y0 - ty) / rise * 1.15;
    FW.rockets.push({
      x: x0, y: y0, vx: U.rand(-14, 14), vy, ay: -vy * 0.55, ty,
      type: o.type || U.pick(['peony', 'chrysanthemum', 'ring', 'willow', 'crackle', 'double']),
      pal: o.pal || U.pick(PAL_KEYS), scale: o.scale || U.rand(0.9, 1.3), size: o.size || 1, onBurst: o.onBurst, silent: !!o.silent
    });
    if (!o.silent && U.Audio.fx) U.Audio.fx.whistle(rise * 0.85, (x0 / FW.w) * 2 - 1);
    ensure();
  };

  /* Direct burst with sound (for shells, shows) */
  FW.shell = function (x, y, type, pal, scale, silent) {
    FW.burst(x, y, type, pal, scale);
    if (!silent && U.Audio.fx) U.Audio.fx.boom(0.6 + (scale || 1) * 0.35, (x / FW.w) * 2 - 1);
  };

  /* Emitter: calls fn(dt, e) every frame until dur has passed */
  FW.addEmitter = function (e) {
    e.age = 0;
    FW.emitters.push(e);
    ensure();
    return e;
  };

  FW.later = function (fn, ms) {
    const id = setTimeout(() => {
      FW.timers = FW.timers.filter((t) => t !== id);
      fn();
    }, ms);
    FW.timers.push(id);
    return id;
  };

  FW.clear = function () {
    FW.timers.forEach(clearTimeout);
    FW.timers = [];
    FW.rockets.length = 0;
    FW.parts.length = 0;
    FW.emitters.length = 0;
    FW.flashes = [];
    if (FW.ctx) FW.ctx.clearRect(0, 0, FW.w, FW.h);
  };

  /* A scheduled show. kind: 'grand' | 'welcome' | 'gentle' | 'moon' */
  FW.show = function (kind, onDone) {
    const rm = U.rm();
    let list = [];
    const W = FW.w, H = FW.h;
    const sx = (f) => W * f;
    if (kind === 'grand') {
      const n = rm ? 8 : 20;
      for (let i = 0; i < n; i++) list.push({ t: i * (rm ? 700 : 520) + U.rand(0, 220), x: U.rand(0.1, 0.9), ty: U.rand(0.12, 0.45) });
      list.push({ t: n * (rm ? 700 : 520) + 300, x: 0.5, ty: 0.28, type: 'willow', pal: 'gold', scale: 1.5 });
    } else if (kind === 'welcome') {
      const n = rm ? 7 : 16;
      for (let i = 0; i < n; i++) list.push({ t: i * (rm ? 800 : 560) + U.rand(0, 260), x: U.rand(0.1, 0.9), ty: U.rand(0.1, 0.42) });
    } else if (kind === 'gentle') {
      const n = rm ? 5 : 11;
      for (let i = 0; i < n; i++) list.push({ t: i * 1500 + U.rand(0, 500), x: U.rand(0.15, 0.85), ty: U.rand(0.12, 0.36), type: U.pick(['willow', 'peony', 'ring']), pal: U.pick(['gold', 'gold', 'orange', 'white', 'pink']), scale: U.rand(0.8, 1.1) });
    } else if (kind === 'moon') {
      const n = rm ? 6 : 12;
      for (let i = 0; i < n; i++) list.push({ t: i * 1100 + U.rand(0, 300), x: U.rand(0.1, 0.9), ty: U.rand(0.12, 0.4), type: i % 3 === 0 ? 'star' : U.pick(['willow', 'crackle', 'ring']), pal: 'gold', scale: U.rand(0.9, 1.2) });
    }
    let last = 0;
    list.forEach((it) => {
      last = Math.max(last, it.t);
      FW.later(() => FW.rocket({ x: sx(it.x), ty: it.ty * H, type: it.type, pal: it.pal, scale: it.scale }), it.t);
    });
    if (onDone) FW.later(onDone, last + 2500);
    return last;
  };

  function frame(now) {
    if (document.hidden) { FW.running = false; return; }
    const dt = FW.last ? Math.min(0.05, (now - FW.last) / 1000) : 0.016;
    FW.last = now;
    const c = FW.ctx;

    // emitters
    for (let i = FW.emitters.length - 1; i >= 0; i--) {
      const e = FW.emitters[i];
      e.age += dt;
      if (e.age > e.dur || e.dead) { FW.emitters.splice(i, 1); if (e.onEnd) e.onEnd(); continue; }
      e.fn(dt, e);
    }

    // rockets
    for (let i = FW.rockets.length - 1; i >= 0; i--) {
      const r = FW.rockets[i];
      r.vy += r.ay * dt;
      r.x += r.vx * dt;
      r.y += r.vy * dt;
      FW.spark({ x: r.x, y: r.y, vx: U.rand(-12, 12), vy: U.rand(10, 50), life: U.rand(0.25, 0.5), h: 36, s: 100, l: 66, size: 1.4, g: 80 });
      if (r.vy >= -20 || r.y <= r.ty) {
        FW.rockets.splice(i, 1);
        FW.burst(r.x, r.y, r.type, r.pal, r.scale);
        if (!r.silent && U.Audio.fx) U.Audio.fx.boom(0.55 + r.scale * 0.4, (r.x / FW.w) * 2 - 1);
        if (r.onBurst) r.onBurst(r);
      }
    }

    // fade previous frame to make trails
    c.globalCompositeOperation = 'destination-out';
    c.fillStyle = 'rgba(0,0,0,' + (U.rm() ? 0.4 : 0.2) + ')';
    c.fillRect(0, 0, FW.w, FW.h);
    c.globalCompositeOperation = 'lighter';

    // flashes
    if (FW.flashes && FW.flashes.length) {
      for (let i = FW.flashes.length - 1; i >= 0; i--) {
        const f = FW.flashes[i];
        f.a -= dt * 2.6;
        if (f.a <= 0) { FW.flashes.splice(i, 1); continue; }
        const g = c.createRadialGradient(f.x, f.y, 0, f.x, f.y, f.r);
        g.addColorStop(0, 'hsla(' + f.h + ',100%,80%,' + f.a * 0.5 + ')');
        g.addColorStop(1, 'hsla(' + f.h + ',100%,60%,0)');
        c.fillStyle = g;
        c.fillRect(f.x - f.r, f.y - f.r, f.r * 2, f.r * 2);
      }
    }

    // particles
    c.lineCap = 'round';
    const parts = FW.parts;
    for (let i = parts.length - 1; i >= 0; i--) {
      const p = parts[i];
      p.life -= dt;
      if (p.life <= 0) {
        parts[i] = parts[parts.length - 1];
        parts.pop();
        continue;
      }
      const k = Math.pow(p.drag, dt * 60);
      p.vx *= k; p.vy = p.vy * k + p.g * dt;
      p.px = p.x; p.py = p.y;
      p.x += p.vx * dt; p.y += p.vy * dt;
      let a = Math.min(1, (p.life / p.max) * 1.6);
      if (p.twinkle && Math.random() < 0.35) a *= 0.2;
      c.strokeStyle = 'hsla(' + p.h + ',' + p.s + '%,' + p.l + '%,' + a.toFixed(2) + ')';
      c.lineWidth = p.size * (0.5 + 0.5 * (p.life / p.max));
      c.beginPath();
      c.moveTo(p.px, p.py);
      c.lineTo(p.x + 0.01, p.y);
      c.stroke();
      if (p.child && Math.random() < 0.28 && parts.length < MAX()) {
        FW.spark({ x: p.x, y: p.y, vx: U.rand(-14, 14), vy: U.rand(-8, 22), life: U.rand(0.3, 0.7), h: p.h, s: p.s, l: Math.min(90, p.l + 10), size: 1.1, g: 70 });
      }
    }
    c.globalCompositeOperation = 'source-over';

    const alive = parts.length || FW.rockets.length || FW.emitters.length || (FW.flashes && FW.flashes.length);
    if (alive) requestAnimationFrame(frame);
    else {
      FW.running = false;
      c.clearRect(0, 0, FW.w, FW.h);
    }
  }

  /* ======================= PARTICLE TEXT ======================= */
  const PT = (U.PText = { cv: null, ctx: null, pts: [], running: false, mode: 'idle', t0: 0, w: 0, h: 0 });
  PT.init = function () {
    PT.cv = U.$('#txt');
    PT.resize();
    window.addEventListener('resize', PT.resize);
  };
  PT.resize = function () {
    const f = fit(PT.cv, 1.5);
    PT.ctx = f.ctx; PT.w = f.w; PT.h = f.h;
  };

  /* Forms text from drifting gold particles. Resolves when formed. */
  PT.form = function (text, opts) {
    opts = opts || {};
    const w = PT.w, h = PT.h;
    const off = document.createElement('canvas');
    const ow = Math.min(w, 900), oh = Math.round(ow * 0.32);
    off.width = ow; off.height = oh;
    const o = off.getContext('2d');
    let fs = Math.min(oh * 0.62, 120);
    const family = '"Cormorant Garamond", Georgia, "Noto Serif", serif';
    o.font = '600 ' + fs + 'px ' + family;
    while (o.measureText(text).width > ow * 0.92 && fs > 18) {
      fs -= 4;
      o.font = '600 ' + fs + 'px ' + family;
    }
    o.textAlign = 'center';
    o.textBaseline = 'middle';
    o.fillStyle = '#fff';
    o.fillText(text, ow / 2, oh / 2);
    const data = o.getImageData(0, 0, ow, oh).data;
    const gap = U.isMobile() ? 3 : 3;
    const pts = [];
    for (let y = 0; y < oh; y += gap) {
      for (let x = 0; x < ow; x += gap) {
        if (data[(y * ow + x) * 4 + 3] > 140) pts.push([x, y]);
      }
    }
    const limit = U.isMobile() ? 700 : 1300;
    let sel = pts;
    if (pts.length > limit) {
      sel = [];
      const step = pts.length / limit;
      for (let i = 0; i < limit; i++) sel.push(pts[Math.floor(i * step)]);
    }
    const cx = w / 2, cy = (opts.yFrac || 0.5) * h;
    const ox = cx - ow / 2, oy = cy - oh / 2;
    PT.pts = sel.map((p) => ({
      tx: ox + p[0], ty: oy + p[1],
      x: cx + U.rand(-w * 0.6, w * 0.6), y: cy + U.rand(-h * 0.5, h * 0.5),
      d: U.rand(0, 0.6), s: U.rand(1, 2.1), tw: U.rand(0, TAU)
    }));
    PT.mode = 'form';
    PT.t0 = performance.now();
    PT.formMs = opts.ms || 2600;
    PT.fade = 1;
    if (!PT.running) { PT.running = true; requestAnimationFrame(ptFrame); }
    return new Promise((res) => setTimeout(res, PT.formMs + 400));
  };

  PT.dissolve = function () { PT.mode = 'dissolve'; PT.t1 = performance.now(); };
  PT.clear = function () {
    PT.mode = 'idle';
    PT.pts = [];
    if (PT.ctx) PT.ctx.clearRect(0, 0, PT.w, PT.h);
  };

  function ptFrame(now) {
    const c = PT.ctx;
    c.clearRect(0, 0, PT.w, PT.h);
    if (document.hidden && PT.mode === 'idle') { PT.running = false; return; }
    if (PT.mode === 'idle') { PT.running = false; return; }
    c.globalCompositeOperation = 'lighter';
    const el = (now - PT.t0) / PT.formMs;
    let alpha = 1;
    if (PT.mode === 'dissolve') {
      alpha = Math.max(0, 1 - (now - PT.t1) / 900);
      if (alpha <= 0) { PT.clear(); return; }
    }
    for (const p of PT.pts) {
      if (PT.mode === 'form') {
        const k = U.clamp((el - p.d) / (1 - p.d * 0.6), 0, 1);
        const e = 1 - Math.pow(1 - k, 3);
        p.x += (p.tx - p.x) * (0.03 + 0.14 * e);
        p.y += (p.ty - p.y) * (0.03 + 0.14 * e);
      } else {
        p.y -= 0.6; p.x += Math.sin(now / 400 + p.tw) * 0.3;
      }
      const tw = 0.65 + 0.35 * Math.sin(now / 260 + p.tw);
      c.fillStyle = 'rgba(255,208,110,' + (0.9 * tw * alpha).toFixed(2) + ')';
      c.beginPath();
      c.arc(p.x, p.y, p.s, 0, TAU);
      c.fill();
    }
    c.globalCompositeOperation = 'source-over';
    requestAnimationFrame(ptFrame);
  }

  U.initFx = function () {
    Sky.init();
    FW.init();
    PT.init();
  };
})();
