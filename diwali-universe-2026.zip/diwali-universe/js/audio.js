/* Diwali Universe 2026 — audio.
   Music: your five uploaded MP3s, one track at a time, fade-out then fade-in.
   Effects: synthesised with WebAudio, so no external sound files are needed. */
(function () {
  'use strict';
  const U = window.U;

  /* Each track lists the uploaded file name first, then the name from the brief as a fallback. */
  const TRACKS = {
    opening: { files: ['assets/audio/opening1.mp3', 'assets/audio/opening.mp3'], gain: 0.9 },
    celebration: { files: ['assets/audio/celebration1.mp3', 'assets/audio/celebration.mp3'], gain: 0.8 },
    traditional: { files: ['assets/audio/traditional.mp3'], gain: 0.85 },
    krishna: { files: ['assets/audio/krishna-flute1.mp3', 'assets/audio/krishna-flute.mp3'], gain: 0.95 },
    ending: { files: ['assets/audio/emotional-ending.mp3'], gain: 0.95 }
  };

  const A = (U.Audio = {
    unlocked: false,
    master: 0.8,
    music: 0.8,
    sfx: 0.8,
    muted: false,
    musicOn: true,
    current: null, // { name, el }
    wanted: null, // track name the current scene wants
    missing: [],
    ctx: null,
    sfxBus: null
  });

  const els = {}; // cached <audio> elements by track name

  function trackVolume(name) {
    if (A.muted || !A.musicOn) return 0;
    return U.clamp(TRACKS[name].gain * A.music * A.master, 0, 1);
  }

  function fadeTo(el, target, ms) {
    return new Promise((res) => {
      if (el._fade) cancelAnimationFrame(el._fade);
      const from = el.volume;
      const t0 = performance.now();
      const step = (now) => {
        const k = ms <= 0 ? 1 : Math.min(1, (now - t0) / ms);
        el.volume = U.clamp(from + (target - from) * k, 0, 1);
        if (k < 1) el._fade = requestAnimationFrame(step);
        else {
          el._fade = 0;
          res();
        }
      };
      el._fade = requestAnimationFrame(step);
    });
  }

  function getEl(name) {
    if (els[name]) return els[name];
    const tr = TRACKS[name];
    const el = new Audio();
    el.preload = 'auto';
    el.loop = true;
    el.volume = 0;
    el._idx = 0;
    el._failed = false;
    el.src = tr.files[0];
    el.addEventListener('error', () => {
      el._idx++;
      if (el._idx < tr.files.length) {
        el.src = tr.files[el._idx];
        if (el._wantPlay) el.play().catch(() => {});
      } else {
        el._failed = true;
        if (!A.missing.includes(tr.files[0])) {
          A.missing.push(tr.files[0]);
          console.warn('[Diwali Universe] Missing music file: ' + tr.files[0]);
          U.toast('Music file missing: ' + tr.files[0].split('/').pop());
        }
      }
    });
    els[name] = el;
    return el;
  }

  /* Ask for a track. Safe to call at any time; it waits for the visitor's first tap.
     Requests run strictly one after another: the old track is faded out and paused
     BEFORE the next one starts, so two music tracks can never overlap. */
  let chain = Promise.resolve();
  A.play = function (name) {
    A.wanted = name;
    if (!A.unlocked) return;
    chain = chain.then(async () => {
      const target = A.wanted; // always the latest request
      if (!A.unlocked || !target) return;
      if (A.current && A.current.name === target) return;
      const prev = A.current;
      A.current = null;
      if (prev) {
        await fadeTo(prev.el, 0, 800);
        prev.el._wantPlay = false;
        prev.el.pause();
      }
      if (A.wanted !== target) return; // superseded while fading; the next queued job handles it
      const el = getEl(target);
      el._wantPlay = true;
      el.currentTime = 0;
      el.volume = 0;
      A.current = { name: target, el };
      try {
        await el.play();
      } catch (e) {
        /* autoplay blocked or file missing: stays silent and retries on the next request */
        A.current = null;
        return;
      }
      fadeTo(el, trackVolume(target), 1600);
    }).catch((e) => console.warn('[Diwali Universe] audio', e));
  };

  A.playingCount = () => Object.values(els).filter((e) => !e.paused).length;

  A.stopMusic = function () {
    A.wanted = null;
    chain = chain.then(async () => {
      const prev = A.current;
      A.current = null;
      if (prev) { await fadeTo(prev.el, 0, 700); prev.el.pause(); }
    });
  };

  A.applyVolumes = function () {
    if (A.current) {
      if (A.current.el._fade) cancelAnimationFrame(A.current.el._fade);
      A.current.el.volume = trackVolume(A.current.name);
    }
    if (A.sfxBus) A.sfxBus.gain.value = A.muted ? 0 : U.clamp(A.sfx * A.master, 0, 1);
  };
  A.setMaster = (v) => { A.master = v; A.applyVolumes(); };
  A.setMusic = (v) => { A.music = v; A.applyVolumes(); };
  A.setSfx = (v) => { A.sfx = v; A.applyVolumes(); };
  A.setMuted = (m) => { A.muted = !!m; A.applyVolumes(); };
  A.setMusicOn = (on) => {
    A.musicOn = !!on;
    A.applyVolumes();
    if (A.musicOn && A.unlocked && !A.current && A.wanted) A.play(A.wanted);
  };

  /* Called from the first tap. Creates the WebAudio graph and starts the wanted track. */
  A.unlock = function () {
    if (A.unlocked) return;
    A.unlocked = true;
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      A.ctx = new AC();
      const comp = A.ctx.createDynamicsCompressor();
      comp.threshold.value = -16;
      comp.ratio.value = 6;
      A.sfxBus = A.ctx.createGain();
      A.sfxBus.gain.value = A.muted ? 0 : A.sfx * A.master;
      A.sfxBus.connect(comp);
      comp.connect(A.ctx.destination);
      A.noise = A.ctx.createBuffer(1, A.ctx.sampleRate * 2, A.ctx.sampleRate);
      const d = A.noise.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    } catch (e) {
      A.ctx = null;
    }
    if (A.ctx && A.ctx.state === 'suspended') A.ctx.resume();
    if (A.wanted && A.musicOn) {
      const w = A.wanted;
      A.current = null;
      A.play(w);
    }
  };

  /* ---------------- Synthesised effects ---------------- */
  let voices = 0;
  let lastBoom = 0;
  const ok = () => A.ctx && A.sfxBus && !A.muted && A.sfx > 0.001;

  function out(node, pan) {
    if (pan && A.ctx.createStereoPanner) {
      const p = A.ctx.createStereoPanner();
      p.pan.value = U.clamp(pan, -1, 1);
      node.connect(p);
      p.connect(A.sfxBus);
    } else node.connect(A.sfxBus);
  }
  function noiseSrc(dur) {
    const s = A.ctx.createBufferSource();
    s.buffer = A.noise;
    s.loop = true;
    s.start(A.ctx.currentTime, Math.random() * 1.5, dur);
    return s;
  }
  function track(ms) {
    voices++;
    setTimeout(() => voices--, ms);
  }

  const S = (A.fx = {});

  S.boom = function (size, pan) {
    if (!ok() || voices > 12) return;
    const now = performance.now();
    if (now - lastBoom < 55) return;
    lastBoom = now;
    size = size || 1;
    const t = A.ctx.currentTime;
    const dur = 0.6 + 0.9 * size;
    track(dur * 700);
    const n = noiseSrc(dur);
    const lp = A.ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(2400 * Math.min(size, 1.3), t);
    lp.frequency.exponentialRampToValueAtTime(110, t + dur);
    const g = A.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.55 * Math.min(size, 1.2), t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    n.connect(lp); lp.connect(g); out(g, pan);
    const o = A.ctx.createOscillator();
    const og = A.ctx.createGain();
    o.frequency.setValueAtTime(95, t);
    o.frequency.exponentialRampToValueAtTime(34, t + 0.35);
    og.gain.setValueAtTime(0.0001, t);
    og.gain.exponentialRampToValueAtTime(0.5 * Math.min(size, 1.1), t + 0.01);
    og.gain.exponentialRampToValueAtTime(0.0001, t + 0.5);
    o.connect(og); out(og, pan);
    o.start(t); o.stop(t + 0.55);
    if (size > 0.7) S.crackle(6 + Math.floor(size * 8), 0.9, pan, 0.12);
  };

  S.crackle = function (count, span, pan, delay) {
    if (!ok()) return;
    const t0 = A.ctx.currentTime + (delay || 0);
    for (let i = 0; i < count; i++) {
      const t = t0 + Math.random() * span;
      const s = A.ctx.createBufferSource();
      s.buffer = A.noise;
      s.start(t, Math.random() * 1.8, 0.03);
      const hp = A.ctx.createBiquadFilter();
      hp.type = 'highpass';
      hp.frequency.value = 2200 + Math.random() * 3000;
      const g = A.ctx.createGain();
      g.gain.setValueAtTime(0.14 * Math.random() + 0.03, t);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.03);
      s.connect(hp); hp.connect(g); out(g, pan);
    }
  };

  S.whistle = function (dur, pan) {
    if (!ok() || voices > 12) return;
    track(dur * 1000);
    const t = A.ctx.currentTime;
    const o = A.ctx.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(500, t);
    o.frequency.exponentialRampToValueAtTime(2300, t + dur);
    const g = A.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.05, t + 0.1);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); out(g, pan);
    o.start(t); o.stop(t + dur + 0.05);
    const n = noiseSrc(dur);
    const bp = A.ctx.createBiquadFilter();
    bp.type = 'bandpass'; bp.frequency.value = 3000; bp.Q.value = 0.8;
    const ng = A.ctx.createGain();
    ng.gain.setValueAtTime(0.0001, t);
    ng.gain.exponentialRampToValueAtTime(0.06, t + 0.08);
    ng.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    n.connect(bp); bp.connect(ng); out(ng, pan);
  };

  /* soft burning hiss with crackles — sparklers and flower pots */
  S.hiss = function (dur, bright, pan, level) {
    if (!ok() || voices > 12) return;
    track(dur * 1000);
    const t = A.ctx.currentTime;
    const n = noiseSrc(dur + 0.2);
    const bp = A.ctx.createBiquadFilter();
    bp.type = 'bandpass'; bp.frequency.value = bright || 4500; bp.Q.value = 0.7;
    const g = A.ctx.createGain();
    const lv = level || 0.12;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(lv, t + 0.15);
    g.gain.setValueAtTime(lv, t + Math.max(0.2, dur - 0.6));
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    n.connect(bp); bp.connect(g); out(g, pan);
    S.crackle(Math.floor(dur * 5), dur, pan, 0.1);
  };

  S.whirr = function (dur, pan) {
    if (!ok() || voices > 12) return;
    track(dur * 1000);
    const t = A.ctx.currentTime;
    const o = A.ctx.createOscillator();
    o.type = 'sawtooth';
    o.frequency.setValueAtTime(140, t);
    o.frequency.linearRampToValueAtTime(520, t + dur * 0.55);
    o.frequency.linearRampToValueAtTime(300, t + dur);
    const lp = A.ctx.createBiquadFilter();
    lp.type = 'lowpass'; lp.frequency.value = 1500;
    const g = A.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.035, t + 0.3);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(lp); lp.connect(g); out(g, pan);
    o.start(t); o.stop(t + dur + 0.05);
    S.hiss(dur, 5200, pan, 0.07);
  };

  S.pop = function (pan) {
    if (!ok() || voices > 14) return;
    track(300);
    const t = A.ctx.currentTime;
    const n = noiseSrc(0.2);
    const lp = A.ctx.createBiquadFilter();
    lp.type = 'lowpass'; lp.frequency.setValueAtTime(1600, t);
    lp.frequency.exponentialRampToValueAtTime(200, t + 0.15);
    const g = A.ctx.createGain();
    g.gain.setValueAtTime(0.3, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.18);
    n.connect(lp); lp.connect(g); out(g, pan);
  };

  S.bell = function (freq, level) {
    if (!ok()) return;
    freq = freq || 880;
    const t = A.ctx.currentTime;
    [1, 2.76, 5.4, 8.93].forEach((m, i) => {
      const o = A.ctx.createOscillator();
      o.type = 'sine';
      o.frequency.value = freq * m;
      const g = A.ctx.createGain();
      const lv = (level || 0.22) / (1 + i * 1.6);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(lv, t + 0.006);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 2.2 / (1 + i * 0.6));
      o.connect(g); out(g, 0);
      o.start(t); o.stop(t + 2.4);
    });
  };

  S.tick = function (final) {
    if (!ok()) return;
    const t = A.ctx.currentTime;
    const o = A.ctx.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(final ? 1320 : 740, t);
    const g = A.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.2, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.35);
    o.connect(g); out(g, 0);
    o.start(t); o.stop(t + 0.4);
  };

  S.shimmer = function () {
    if (!ok()) return;
    const t0 = A.ctx.currentTime;
    [1568, 1976, 2349, 2637, 3136].forEach((f, i) => {
      const t = t0 + i * 0.07;
      const o = A.ctx.createOscillator();
      o.type = 'triangle';
      o.frequency.value = f;
      const g = A.ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.07, t + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.9);
      o.connect(g); out(g, 0);
      o.start(t); o.stop(t + 1);
    });
  };

  S.whoosh = function () {
    if (!ok()) return;
    const t = A.ctx.currentTime;
    const n = noiseSrc(1.2);
    const bp = A.ctx.createBiquadFilter();
    bp.type = 'bandpass'; bp.Q.value = 1.2;
    bp.frequency.setValueAtTime(300, t);
    bp.frequency.exponentialRampToValueAtTime(2200, t + 0.9);
    const g = A.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.14, t + 0.4);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 1.1);
    n.connect(bp); bp.connect(g); out(g, 0);
  };
})();
