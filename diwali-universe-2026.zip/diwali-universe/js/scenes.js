/* Diwali Universe 2026 — scene manager and the full journey. */
(function () {
  'use strict';
  const U = window.U;
  const $ = U.$, $$ = U.$$;
  const A = U.Audio, FW = U.FW, PT = U.PText, Sky = U.Sky;
  const fx = () => A.fx;

  const S = (U.Scenes = { cur: null, busy: false, tl: null, skipFn: null });
  const defs = {};

  /* ---------------------------------------------------------------
     Scene manager: fade out → clean up → fade in. One track at a time.
  --------------------------------------------------------------- */
  function setBg(name) {
    $$('.bg').forEach((b) => b.classList.toggle('on', b.dataset.bg === name));
  }
  function setSkip(fn) {
    S.skipFn = fn || null;
    $('#btnSkip').hidden = !fn;
  }

  S.go = async function (id) {
    if (S.busy) return;
    S.busy = true;
    const next = defs[id];
    const prev = S.cur ? defs[S.cur] : null;
    setSkip(null);
    if (prev) {
      if (S.tl) S.tl.cancel();
      $('#s-' + S.cur).classList.remove('active');
      try { prev.exit && prev.exit(); } catch (e) { console.warn(e); }
      if (!next.keepFx) { FW.clear(); PT.clear(); }
      await U.sleep(U.rm() ? 250 : 750);
    }
    if (next.music) A.play(next.music);
    setBg(next.bg);
    S.cur = id;
    S.tl = new U.Timeline();
    document.body.dataset.scene = id;
    $('#s-' + id).classList.add('active');
    S.busy = false;
    try { await next.enter(S.tl); } catch (e) { if (e && e.message !== 'cancelled') console.error(e); }
  };

  /* ---------------------------------------------------------------
     Text helpers
  --------------------------------------------------------------- */
  function splitReveal(el, text, perChar) {
    el.innerHTML = '';
    el.classList.remove('out', 'show');
    const words = text.split(' ');
    let i = 0;
    words.forEach((w, wi) => {
      const ws = document.createElement('span');
      ws.className = 'w';
      [...w].forEach((ch) => {
        const s = document.createElement('span');
        s.className = 'ch';
        s.textContent = ch;
        s.style.animationDelay = i++ * (perChar || 55) + 'ms';
        ws.appendChild(s);
      });
      el.appendChild(ws);
      if (wi < words.length - 1) { el.appendChild(document.createTextNode(' ')); i++; }
    });
    void el.offsetWidth;
    el.classList.add('show');
    return i * (perChar || 55) + 900;
  }
  function restartAnim(el, cls) { el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls); }
  function show(el, on) { el.hidden = !on; }
  const nm = () => U.visitor.name || 'Friend';

  /* ---------------------------------------------------------------
     0 · Gate
  --------------------------------------------------------------- */
  defs.gate = {
    bg: 'night',
    enter() {},
    exit() {}
  };

  /* ---------------------------------------------------------------
     1 · Opening
  --------------------------------------------------------------- */
  defs.opening = {
    bg: 'night', music: 'opening',
    async enter(tl) {
      const l1 = $('#ol1'), l2 = $('#ol2');
      l1.innerHTML = ''; l2.innerHTML = '';
      l1.classList.remove('show', 'out'); l2.classList.remove('show', 'out');
      setSkip(() => S.go('ask'));
      try {
        await tl.wait(1200);
        Sky.setStars(1);
        await tl.wait(2200);
        Sky.setMotes(1);
        await tl.wait(1200);
        const d1 = splitReveal(l1, 'A little universe of happiness...', U.rm() ? 12 : 62);
        await tl.wait(d1 + 1800);
        l1.classList.add('out');
        await tl.wait(1100);
        const d2 = splitReveal(l2, 'Beautifully created by R. Ashwin.', U.rm() ? 12 : 58);
        await tl.wait(d2 + 1800);
        l2.classList.add('out');
        await tl.wait(1100);
        S.go('ask');
      } catch (e) {}
    },
    exit() {}
  };

  /* ---------------------------------------------------------------
     2 · Questions
  --------------------------------------------------------------- */
  function askStep(n) {
    $$('.ask-step').forEach((s) => {
      const k = Number(s.dataset.step);
      s.classList.toggle('active', k === n);
      s.classList.toggle('past', k < n);
    });
    const inp = $('#nameInput');
    if (n === 1) setTimeout(() => inp.focus({ preventScroll: true }), 500);
  }
  function selectChip(group, btn) {
    $$('.chip', group).forEach((c) => c.setAttribute('aria-checked', String(c === btn)));
    $$('.chip', group).forEach((c) => c.classList.toggle('on', c === btn));
  }
  function submitName() {
    const raw = $('#nameInput').value;
    const clean = U.cleanName(raw);
    const hint = $('#nameHint');
    if (!/\p{L}/u.test(clean)) {
      hint.textContent = 'Please tell me your name so I can greet you properly.';
      restartAnim($('#nameInput').parentElement, 'shake');
      return;
    }
    hint.textContent = '';
    U.visitor.name = clean;
    U.visitor.isMalar = U.isMalarMeena(clean);
    $('#nameInput').blur();
    askStep(2);
  }
  defs.ask = {
    bg: 'night', music: 'opening',
    enter() {
      U.visitor.name = ''; U.visitor.gender = ''; U.visitor.relation = ''; U.visitor.isMalar = false;
      $('#nameInput').value = '';
      $('#nameHint').textContent = '';
      $$('.chip').forEach((c) => { c.classList.remove('on'); c.setAttribute('aria-checked', 'false'); });
      Sky.setStars(1); Sky.setMotes(1);
      askStep(1);
    },
    exit() { $('#nameInput').blur(); }
  };

  /* ---------------------------------------------------------------
     3 · Name reveal → countdown → fireworks → greeting
  --------------------------------------------------------------- */
  const Clock = {
    id: 0, last: '',
    start() { this.stop(); this.render(); this.id = setInterval(() => this.render(), 250); },
    stop() { clearInterval(this.id); this.id = 0; this.last = ''; },
    render() {
      const st = U.diwaliState();
      const key = st.phase + ':' + st.days + ':' + st.hours + ':' + st.minutes + ':' + st.seconds;
      if (key === this.last) return;
      this.last = key;
      const grid = $('#clockGrid'), msg = $('#clockMsg'), title = $('#clockTitle');
      const p2 = (n) => String(n).padStart(2, '0');
      if (st.phase === 'before') {
        title.innerHTML = 'Diwali begins in<small>Sunday, 8 November 2026 · IST</small>';
        grid.hidden = false; msg.hidden = true;
        $('#cDays').textContent = p2(st.days);
        $('#cHours').textContent = p2(st.hours);
        $('#cMins').textContent = p2(st.minutes);
        $('#cSecs').textContent = p2(st.seconds);
        restartAnim($('#cSecs'), 'tick');
      } else if (st.phase === 'today') {
        title.textContent = '';
        grid.hidden = true; msg.hidden = false;
        msg.innerHTML = 'Diwali is here! Let the celebration shine!';
      } else {
        title.textContent = '';
        grid.hidden = true; msg.hidden = false;
        msg.innerHTML = 'Diwali has passed, but its light stays with us. Wishing you a bright and joyful year ahead!<span class="ta">தீபாவளி கடந்து சென்றாலும், அதன் ஒளி உங்களுடன் என்றும் நிலைத்திருக்கட்டும்.</span>';
      }
    }
  };

  function fillReveal() {
    const v = U.visitor;
    $('#rvDear').textContent = 'Dear ' + nm() + '!';
    if (v.isMalar) {
      $('#rvRel').textContent = U.MALAR_EN;
      $('#rvTa').textContent = U.MALAR_TA;
      show($('#rvTa'), true);
    } else {
      $('#rvRel').textContent = U.greetingFor(v);
      show($('#rvTa'), false);
    }
    $('#moonWrap').classList.toggle('on', !!v.isMalar);
    $('#revealCard').classList.add('show');
    Clock.start();
  }

  defs.reveal = {
    bg: 'night', music: 'celebration',
    async enter(tl) {
      const v = U.visitor;
      $('#revealCard').classList.remove('show');
      $('#rvNext').hidden = true;
      $('#cdWrap').classList.remove('on');
      $('#moonWrap').classList.remove('on');
      Sky.setStars(1); Sky.setMotes(1);
      setSkip(() => this.skip());
      try {
        await tl.wait(700);
        await PT.form(nm(), { yFrac: 0.3, ms: U.rm() ? 1200 : 2800 });
        await tl.wait(U.rm() ? 600 : 1100);
        const cd = $('#cdNum');
        $('#cdWrap').classList.add('on');
        for (let n = 5; n >= 1; n--) {
          cd.textContent = n;
          restartAnim(cd, 'pop');
          if (fx()) fx().tick(false);
          await tl.wait(1000);
        }
        $('#cdWrap').classList.remove('on');
        if (fx()) { fx().tick(true); fx().boom(1.3, 0); fx().whoosh(); }
        restartAnim($('#fade'), 'flash');
        PT.dissolve();
        FW.show('welcome');
        if (v.isMalar) FW.later(() => FW.show('moon'), 3500);
        await tl.wait(900);
        fillReveal();
        setSkip(null);
        await tl.wait(U.rm() ? 1500 : 3500);
        $('#rvNext').hidden = false;
      } catch (e) {}
    },
    skip() {
      if (S.tl) S.tl.cancel();
      $('#cdWrap').classList.remove('on');
      PT.clear();
      FW.show(U.visitor.isMalar ? 'moon' : 'welcome');
      fillReveal();
      $('#rvNext').hidden = false;
      setSkip(null);
    },
    exit() { Clock.stop(); $('#cdWrap').classList.remove('on'); }
  };

  /* ---------------------------------------------------------------
     4 · Traditional entrance
  --------------------------------------------------------------- */
  function rangoliSvg(size) {
    const cols = ['#ff4f81', '#ff9a1f', '#ffd23f', '#7be0a8', '#4fc3ff', '#b57bff'];
    let s = '<svg viewBox="-100 -100 200 200" width="' + size + '" height="' + size + '" aria-hidden="true"><circle r="96" fill="#1c0912" opacity=".55"/>';
    [[88, 24, 9, 0], [68, 16, 8, 1], [48, 12, 7, 2], [30, 8, 6, 3]].forEach((ring, ri) => {
      for (let i = 0; i < ring[1]; i++) {
        const a = (i / ring[1]) * 360 + (ri % 2) * 8;
        s += '<ellipse cx="' + ring[0] + '" cy="0" rx="' + ring[2] * 1.25 + '" ry="' + ring[2] * 0.55 + '" fill="' + cols[(i + ri) % cols.length] + '" transform="rotate(' + a + ')"/>';
      }
    });
    for (let i = 0; i < 8; i++) s += '<circle cx="' + 100 * 0.18 + '" cy="0" r="4" fill="#fff1d6" transform="rotate(' + i * 45 + ')"/>';
    s += '<circle r="9" fill="#ffd23f"/><circle r="4" fill="#d6336c"/></svg>';
    return s;
  }

  function lampsRow(el, n, size) {
    el.innerHTML = '';
    for (let i = 0; i < n; i++) {
      const l = document.createElement('i');
      l.className = 'lamp';
      l.style.setProperty('--d', (Math.random() * 2).toFixed(2) + 's');
      el.appendChild(l);
    }
  }

  function buildEntrance() {
    const bells = $('#entBells');
    bells.innerHTML = '';
    for (let i = 0; i < 7; i++) {
      const x = 10 + i * 13.3;
      const arc = Math.pow(Math.abs(x - 50) / 50, 2) * 24;
      const d = document.createElement('div');
      d.className = 'bell';
      d.style.left = x + '%';
      d.style.top = 6 + arc + '%';
      d.style.setProperty('--delay', (-Math.random() * 3).toFixed(2) + 's');
      d.style.setProperty('--sz', 0.8 + Math.random() * 0.45);
      d.innerHTML = U.Art.bell();
      bells.appendChild(d);
    }
    const lights = $('#entLights');
    lights.innerHTML = '';
    const pts = [];
    for (let i = 0; i < 9; i++) pts.push([3, 95 - (i * 65) / 8]);
    for (let i = 1; i < 16; i++) { const phi = (i / 16) * Math.PI; pts.push([50 - 47 * Math.cos(phi), 30 - 27 * Math.sin(phi)]); }
    for (let i = 0; i < 9; i++) pts.push([97, 30 + (i * 65) / 8]);
    pts.forEach((p, i) => {
      const b = document.createElement('i');
      b.style.left = p[0] + '%'; b.style.top = p[1] + '%';
      b.style.setProperty('--d', ((i % 5) * 0.4).toFixed(1) + 's');
      b.className = 'fl c' + (i % 3);
      lights.appendChild(b);
    });
    $('#entGarTop').innerHTML = U.Art.garland(400, 38, 22) + U.Art.garland(400, 62, 20);
    lampsRow($('#entLamps'), 5);
    lampsRow($('#floorDiyas'), 5);
    $('#floorRangoli').innerHTML = rangoliSvg(220);
  }

  defs.entrance = {
    bg: 'entrance', music: 'traditional',
    async enter(tl) {
      const world = $('#entWorld'), arch = $('#entArch'), txt = $('#entText');
      world.className = 'ent-world';
      arch.classList.remove('open');
      txt.classList.remove('show');
      Sky.setStars(0.6); Sky.setMotes(1);
      void world.offsetWidth;
      setSkip(() => S.go('gods'));
      const rm = U.rm();
      try {
        await tl.wait(500);
        world.classList.add(rm ? 'cam-rm' : 'cam');
        txt.textContent = 'Welcome home.';
        txt.classList.add('show');
        await tl.wait(rm ? 1200 : 3000);
        if (fx()) fx().bell(523, 0.12);
        arch.classList.add('open');
        await tl.wait(rm ? 1200 : 2500);
        txt.classList.remove('show');
        await tl.wait(500);
        txt.textContent = 'Every lamp is lit for you.';
        txt.classList.add('show');
        await tl.wait(rm ? 1800 : 4200);
        S.go('gods');
      } catch (e) {}
    },
    exit() { $('#entWorld').className = 'ent-world'; }
  };

  /* ---------------------------------------------------------------
     5 · Three little gods
  --------------------------------------------------------------- */
  defs.gods = {
    bg: 'gods', music: 'krishna',
    async enter(tl) {
      const row = $('#godsRow'), card = $('#godsCard');
      $('#gEn').textContent = 'Happy Diwali, dear ' + nm() + '!';
      row.classList.remove('in');
      card.classList.remove('show');
      $('#godsNext').hidden = true;
      Sky.setStars(0.8); Sky.setMotes(0.8);
      setSkip(() => { $('#godsNext').hidden = false; card.classList.add('show'); row.classList.add('in'); setSkip(null); });
      // distant fountains and gentle far-away fireworks
      const H = FW.h, W = FW.w;
      const fountain = (xf) =>
        FW.addEmitter({
          x: W * xf, y: H * 0.5, dur: 40,
          fn(dt, e) {
            if (Math.random() < dt * 7) {
              const a = -Math.PI / 2 + U.rand(-0.35, 0.35), v = U.rand(120, 210);
              FW.spark({ x: e.x, y: e.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: U.rand(0.7, 1.1), h: U.pick([40, 44, 330, 30]), s: 100, l: 68, size: 1.3, g: 260, drag: 0.97 });
            }
          }
        });
      try {
        await tl.wait(500);
        row.classList.add('in');
        fountain(0.14); fountain(0.86);
        if (!U.rm()) {
          const far = () => {
            FW.rocket({ x: U.rand(W * 0.2, W * 0.8), ty: U.rand(H * 0.12, H * 0.3), scale: 0.55, silent: true, pal: U.pick(['gold', 'pink', 'blue', 'orange']), type: U.pick(['peony', 'crackle']) });
          };
          for (let i = 0; i < 5; i++) FW.later(far, 1500 + i * 2300);
        }
        await tl.wait(2400);
        card.classList.add('show');
        await tl.wait(U.rm() ? 3000 : 6500);
        $('#godsNext').hidden = false;
        setSkip(null);
      } catch (e) {}
    },
    exit() {}
  };

  /* ---------------------------------------------------------------
     6 · Crackers
  --------------------------------------------------------------- */
  defs.crackers = {
    bg: 'crackers', music: 'celebration',
    enter() {
      Sky.setStars(1); Sky.setMotes(0.4);
      U.Crackers.enter();
      const h = $('#crHint');
      h.classList.add('show');
      clearTimeout(defs.crackers._t);
      defs.crackers._t = setTimeout(() => h.classList.remove('show'), 7000);
    },
    exit() { U.Crackers.exit(); }
  };

  /* ---------------------------------------------------------------
     7 · Sweets
  --------------------------------------------------------------- */
  const SWEETS = {
    kk: { name: 'Kaju Katli', text: 'Smooth cashew fudge cut into diamonds and finished with a touch of edible silver.', photo: 'kaju-katli' },
    gj: { name: 'Gulab Jamun', text: 'Soft milk dumplings fried golden and soaked in warm rose and cardamom syrup.', photo: 'gulab-jamun' },
    mp: { name: 'Mysore Pak', text: 'A rich gram flour and ghee sweet from Mysuru, crumbly outside and melting inside.', photo: 'mysore-pak' }
  };
  function buildSweets() {
    $('#swKK').innerHTML = U.Art.kajuKatli();
    $('#swGJ').innerHTML = U.Art.gulabJamun();
    $('#swMP').innerHTML = U.Art.mysorePak();
    // Optional: drop real photos into assets/images/sweets/ (kaju-katli.jpg, gulab-jamun.jpg, mysore-pak.jpg)
    Object.keys(SWEETS).forEach((k) => {
      const img = new Image();
      img.alt = SWEETS[k].name;
      img.decoding = 'async';
      img.onload = () => {
        const host = $('#sw' + k.toUpperCase());
        host.innerHTML = '';
        host.classList.add('photo');
        host.appendChild(img);
      };
      img.src = 'assets/images/sweets/' + SWEETS[k].photo + '.jpg';
    });
    $$('.sweet').forEach((b) => {
      b.addEventListener('click', () => {
        const d = SWEETS[b.dataset.id];
        $$('.sweet').forEach((x) => x.classList.toggle('sel', x === b));
        $('#sweetNote').innerHTML = '<b>' + d.name + '.</b> ' + d.text;
        if (fx()) fx().shimmer();
        const r = b.getBoundingClientRect();
        for (let i = 0; i < 22; i++) {
          const a = U.rand(0, Math.PI * 2), v = U.rand(30, 120);
          FW.spark({ x: r.left + r.width / 2, y: r.top + r.height / 2, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 30, life: U.rand(0.5, 1), h: U.rand(38, 50), s: 100, l: 72, size: 1.5, g: 90 });
        }
      });
    });
  }
  defs.sweets = {
    bg: 'hall', music: 'traditional',
    enter() {
      Sky.setStars(0); Sky.setMotes(1);
      $$('.sweet').forEach((x) => x.classList.remove('sel'));
      $('#sweetNote').textContent = 'Tap a sweet to learn about it.';
      $('#platter').classList.remove('in');
      void $('#platter').offsetWidth;
      $('#platter').classList.add('in');
    },
    exit() {}
  };

  /* ---------------------------------------------------------------
     8 · Rangoli
  --------------------------------------------------------------- */
  defs.rangoli = {
    bg: 'hall', music: 'traditional',
    enter() { Sky.setStars(0); Sky.setMotes(1); U.Rangoli.enter(); },
    exit() { U.Rangoli.exit(); }
  };

  /* ---------------------------------------------------------------
     9 · Diya
  --------------------------------------------------------------- */
  const Diya = { lit: false, raf: 0, em: null };
  function diyaFlicker(now) {
    const f = $('#diyaFlame'), g = $('#diyaGlow');
    if (!f || !Diya.lit) return;
    const k = Diya.ramp = Math.min(1, (Diya.ramp || 0) + 0.012);
    const n = Math.sin(now / 83) * 0.05 + Math.sin(now / 41) * 0.04 + Math.sin(now / 197) * 0.06;
    f.style.transform = 'scale(' + (k * (1 + n * 0.8)).toFixed(3) + ',' + (k * (1 + n * 1.6)).toFixed(3) + ') rotate(' + (n * 14).toFixed(2) + 'deg)';
    g.setAttribute('opacity', (k * (0.8 + n)).toFixed(3));
    Diya.raf = requestAnimationFrame(diyaFlicker);
  }
  function lightDiya() {
    if (Diya.lit) return;
    Diya.lit = true; Diya.ramp = 0;
    $('#s-diya').classList.add('lit');
    $('#diyaHint').hidden = true;
    if (fx()) { fx().bell(660, 0.22); setTimeout(() => fx() && fx().bell(990, 0.12), 350); setTimeout(() => fx() && fx().shimmer(), 900); }
    Diya.raf = requestAnimationFrame(diyaFlicker);
    const r = $('#diyaBtn').getBoundingClientRect();
    const x = r.left + r.width * 0.5, y = r.top + r.height * 0.3;
    FW.addEmitter({
      x, y, dur: 9,
      fn(dt) {
        if (Math.random() < dt * 22) FW.spark({ x: x + U.rand(-14, 14), y: y + U.rand(-4, 8), vx: U.rand(-14, 14), vy: U.rand(-55, -18), life: U.rand(1.4, 2.6), h: U.rand(36, 50), s: 100, l: U.rand(65, 80), size: 1.6, g: -4, drag: 0.99, twinkle: Math.random() < 0.4 });
      }
    });
    for (let i = 0; i < 26; i++) {
      const a = U.rand(0, Math.PI * 2), v = U.rand(40, 150);
      FW.spark({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 30, life: U.rand(0.7, 1.4), h: 42, s: 100, l: 72, size: 1.6, g: 40 });
    }
    setTimeout(() => { show($('#diyaTa'), true); $('#diyaTa').classList.add('show'); }, 900);
    setTimeout(() => { $('#diyaNext').hidden = false; }, 2600);
  }
  defs.diya = {
    bg: 'hall', music: 'traditional',
    enter() {
      Diya.lit = false;
      cancelAnimationFrame(Diya.raf);
      $('#s-diya').classList.remove('lit');
      $('#diyaFlame').style.transform = 'scale(0)';
      $('#diyaGlow').setAttribute('opacity', '0');
      $('#diyaTa').hidden = true; $('#diyaTa').classList.remove('show');
      $('#diyaNext').hidden = true;
      $('#diyaHint').hidden = false;
      Sky.setStars(0); Sky.setMotes(0.8);
    },
    exit() { cancelAnimationFrame(Diya.raf); Diya.lit = false; }
  };

  /* ---------------------------------------------------------------
     10 · Gift
  --------------------------------------------------------------- */
  const Gift = { opened: false };
  function openGift() {
    if (Gift.opened) return;
    Gift.opened = true;
    const btn = $('#giftBtn');
    btn.classList.add('opening');
    $('#giftHint').classList.add('gone');
    if (fx()) fx().whoosh();
    const tl = S.tl;
    const r = btn.getBoundingClientRect();
    const x = r.left + r.width / 2, y = r.top + r.height * 0.42;
    setTimeout(() => btn.classList.add('lifted'), 1000);
    setTimeout(() => {
      if (fx()) { fx().shimmer(); fx().bell(784, 0.1); }
      FW.addEmitter({
        x, y, dur: 3.2,
        fn(dt) {
          const n = Math.round(110 * dt);
          for (let i = 0; i < n; i++) {
            const a = -Math.PI / 2 + U.rand(-0.9, 0.9), v = U.rand(80, 330);
            FW.spark({ x: x + U.rand(-40, 40), y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: U.rand(0.9, 1.8), h: U.rand(36, 50), s: 100, l: U.rand(62, 80), size: 1.8, g: 160, drag: 0.97, twinkle: Math.random() < 0.3 });
          }
        }
      });
    }, 1700);
    setTimeout(() => {
      const b = U.giftBlessing(U.visitor);
      $('#gcName').textContent = 'For ' + nm();
      $('#gcEn').textContent = b[0];
      $('#gcTa').textContent = b[1];
      $('#giftCard').hidden = false;
      void $('#giftCard').offsetWidth;
      $('#giftCard').classList.add('show');
    }, 2700);
  }
  defs.gift = {
    bg: 'hall', music: 'traditional',
    enter() {
      Gift.opened = false;
      const btn = $('#giftBtn');
      btn.className = 'gift-btn';
      $('#giftCard').hidden = true; $('#giftCard').classList.remove('show');
      $('#giftHint').classList.remove('gone');
      Sky.setStars(0.4); Sky.setMotes(1);
    },
    exit() { Gift.opened = false; }
  };

  /* ---------------------------------------------------------------
     11 · Emotional ending
  --------------------------------------------------------------- */
  function buildEndDiyas() {
    const el = $('#endDiyas');
    el.innerHTML = '';
    for (let i = 0; i < 9; i++) {
      const l = document.createElement('i');
      l.className = 'lamp';
      l.style.setProperty('--d', (Math.random() * 2).toFixed(2) + 's');
      l.style.setProperty('--i', i);
      el.appendChild(l);
    }
  }
  const END_IDS = ['eHappy', 'eMalar', 'eMalarTa', 'eEn', 'eTa', 'eWith', 'eFinal'];
  function endFinal() {
    END_IDS.forEach((id) => { const e = $('#' + id); if (!e.hidden) e.classList.add('show'); });
  }
  defs.ending = {
    bg: 'ending', music: 'ending',
    async enter(tl) {
      const v = U.visitor;
      $('#eHappy').textContent = 'Happy Diwali, dear ' + nm() + '!';
      $('#endText').classList.remove('final');
      END_IDS.forEach((id) => $('#' + id).classList.remove('show'));
      show($('#eMalar'), v.isMalar); show($('#eMalarTa'), v.isMalar);
      $('#eMalar').textContent = U.MALAR_EN;
      $('#eMalarTa').textContent = U.MALAR_TA;
      $('#moonWrap2').classList.toggle('on', !!v.isMalar);
      $('#endDiyas').classList.remove('on');
      buildEndDiyas();
      Sky.setStars(1); Sky.setMotes(1);
      setSkip(() => this.skip());
      const rm = U.rm();
      const gap = rm ? 900 : 3000;
      try {
        await tl.wait(1200);
        $('#endDiyas').classList.add('on');
        await tl.wait(rm ? 800 : 2600);
        $('#eHappy').classList.add('show');
        await tl.wait(gap);
        if (v.isMalar) {
          $('#eMalar').classList.add('show'); await tl.wait(gap);
          $('#eMalarTa').classList.add('show'); await tl.wait(gap);
        }
        FW.show(v.isMalar ? 'moon' : 'gentle');
        $('#eEn').classList.add('show');
        await tl.wait(gap + 800);
        $('#eTa').classList.add('show');
        await tl.wait(gap + 800);
        $('#eWith').classList.add('show');
        await tl.wait(gap + 1200);
        // grand but peaceful finale: slow golden willows, one after another
        const n = rm ? 3 : 7;
        for (let i = 0; i < n; i++) {
          FW.rocket({ x: FW.w * (0.14 + (i / (n - 1 || 1)) * 0.72), ty: FW.h * U.rand(0.14, 0.3), type: i === 3 ? 'star' : 'willow', pal: 'gold', scale: 1.15 });
          await tl.wait(rm ? 700 : 900);
        }
        await tl.wait(2200);
        $('#endText').classList.add('final');
        $('#eFinal').classList.add('show');
        setSkip(null);
      } catch (e) {}
    },
    skip() {
      if (S.tl) S.tl.cancel();
      $('#endText').classList.add('final');
      END_IDS.forEach((id) => { const e = $('#' + id); if (!e.hidden) e.classList.add('show'); });
      $('#endDiyas').classList.add('on');
      FW.show('gentle');
      setSkip(null);
    },
    exit() {}
  };

  /* ---------------------------------------------------------------
     HUD, settings, boot
  --------------------------------------------------------------- */
  function updateSoundIcon() {
    const m = A.muted;
    $('#icoSound').setAttribute('d', m
      ? 'M4 9v6h4l5 4V5L8 9H4zm12.6 3-2.4-2.4 1.4-1.4 2.4 2.4 2.4-2.4 1.4 1.4-2.4 2.4 2.4 2.4-1.4 1.4-2.4-2.4-2.4 2.4-1.4-1.4z'
      : 'M4 9v6h4l5 4V5L8 9H4zm12.5 3a4.5 4.5 0 0 0-2.5-4v8a4.5 4.5 0 0 0 2.5-4z');
    $('#btnSound').setAttribute('aria-pressed', String(m));
    $('#muteAll').checked = m;
  }
  function applyMotion(on) {
    U.reducedMotion.on = !!on;
    document.body.classList.toggle('reduced', !!on);
    $('#reduceMotion').checked = !!on;
  }

  function bind() {
    $('#enter-sound').addEventListener('click', () => { A.unlock(); updateSoundIcon(); begin(); });
    $('#enter-quiet').addEventListener('click', () => { A.unlock(); A.setMuted(true); updateSoundIcon(); begin(); });
    function begin() {
      $('#hud').classList.remove('hidden');
      S.go('opening');
    }

    // HUD
    $('#btnSound').addEventListener('click', () => { A.setMuted(!A.muted); updateSoundIcon(); });
    $('#btnSettings').addEventListener('click', () => {
      const p = $('#panel');
      p.hidden = !p.hidden;
      $('#btnSettings').setAttribute('aria-expanded', String(!p.hidden));
    });
    document.addEventListener('pointerdown', (e) => {
      const p = $('#panel');
      if (!p.hidden && !p.contains(e.target) && !$('#btnSettings').contains(e.target)) { p.hidden = true; $('#btnSettings').setAttribute('aria-expanded', 'false'); }
    });
    $('#btnSkip').addEventListener('click', () => { if (S.skipFn) S.skipFn(); });
    $('#volMaster').addEventListener('input', (e) => A.setMaster(e.target.value / 100));
    $('#volMusic').addEventListener('input', (e) => A.setMusic(e.target.value / 100));
    $('#volSfx').addEventListener('input', (e) => { A.setSfx(e.target.value / 100); });
    $('#volSfx').addEventListener('change', () => fx() && fx().bell(880, 0.1));
    $('#musicOn').addEventListener('change', (e) => A.setMusicOn(e.target.checked));
    $('#muteAll').addEventListener('change', (e) => { A.setMuted(e.target.checked); updateSoundIcon(); });
    $('#reduceMotion').addEventListener('change', (e) => applyMotion(e.target.checked));

    // questions
    $('#nameNext').addEventListener('click', submitName);
    $('#nameInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); submitName(); } });
    $('#genderChips').addEventListener('click', (e) => {
      const b = e.target.closest('.chip');
      if (!b) return;
      selectChip($('#genderChips'), b);
      U.visitor.gender = b.dataset.v;
      setTimeout(() => askStep(3), 350);
    });
    $('#genderSkip').addEventListener('click', () => { U.visitor.gender = ''; askStep(3); });
    $('#relChips').addEventListener('click', (e) => {
      const b = e.target.closest('.chip');
      if (!b) return;
      selectChip($('#relChips'), b);
      U.visitor.relation = b.dataset.v;
      setTimeout(() => S.go('reveal'), 450);
    });

    // journey buttons
    $('#rvNext').addEventListener('click', () => S.go('entrance'));
    $('#godsNext').addEventListener('click', () => S.go('crackers'));
    $('#crNext').addEventListener('click', () => S.go('sweets'));
    $('#sweetsNext').addEventListener('click', () => S.go('rangoli'));
    $('#rgNext').addEventListener('click', () => S.go('diya'));
    $('#diyaBtn').addEventListener('click', lightDiya);
    $('#diyaNext').addEventListener('click', () => S.go('gift'));
    $('#giftBtn').addEventListener('click', openGift);
    $('#giftNext').addEventListener('click', () => S.go('ending'));
    $('#endCrackers').addEventListener('click', () => S.go('crackers'));
    $('#endRestart').addEventListener('click', () => S.go('ask'));
  }

  function buildStatic() {
    $('#godsRow').innerHTML = '<div class="god-wrap g-h">' + U.Art.hanuman() + '</div><div class="god-wrap g-k">' + U.Art.krishna() + '</div><div class="god-wrap g-g">' + U.Art.ganesha() + '</div>';
    $('#godsGarland').innerHTML = U.Art.garland(600, 44, 28);
    $('#diyaBtn').innerHTML = U.Art.diya();
    $('#giftBtn').innerHTML = U.Art.gift();
    buildEntrance();
    buildSweets();
  }

  function boot() {
    U.initFx();
    U.Crackers.init();
    U.Rangoli.init();
    buildStatic();
    bind();
    applyMotion(U.reducedMotion.on);
    updateSoundIcon();
    document.body.classList.remove('booting');
    setBg('night');
    $('#s-gate').classList.add('active');
    S.cur = 'gate';
    Sky.setStars(0.35);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
