/* Diwali Universe 2026 — interactive rangoli.
   Every tap or drag stamps petals, dots and flowers that mirror eight ways around the centre.
   As the pattern grows, small brass diyas around the rim wake up and glow. */
(function () {
  'use strict';
  const U = window.U;
  const TAU = Math.PI * 2;
  const COLORS = ['#ff4f81', '#ff9a1f', '#ffd23f', '#7be0a8', '#4fc3ff', '#b57bff', '#ff6b3d', '#fff1d6'];
  const R = (U.Rangoli = { cv: null, ctx: null, layer: null, lctx: null, size: 300, cx: 0, cy: 0, rad: 0, stamps: 0, parts: [], diyas: [], active: false, running: false, last: 0, down: false, lastPt: null, timers: [], dpr: 1 });

  R.init = function () {
    R.cv = U.$('#rg');
    const cv = R.cv;
    cv.addEventListener('pointerdown', (e) => {
      cv.setPointerCapture && cv.setPointerCapture(e.pointerId);
      R.down = true;
      const p = pt(e);
      R.lastPt = p;
      R.stampAt(p.x, p.y, true);
    });
    cv.addEventListener('pointermove', (e) => {
      if (!R.down) return;
      const p = pt(e);
      if (!R.lastPt || Math.hypot(p.x - R.lastPt.x, p.y - R.lastPt.y) > Math.max(16, R.size * 0.045)) {
        R.lastPt = p;
        R.stampAt(p.x, p.y, false);
      }
    });
    const up = () => { R.down = false; R.lastPt = null; };
    cv.addEventListener('pointerup', up);
    cv.addEventListener('pointercancel', up);
    cv.addEventListener('pointerleave', up);
    window.addEventListener('resize', () => { if (R.active) R.layout(true); });
    U.$('#rgClear').addEventListener('click', R.reset);
    U.$('#rgFill').addEventListener('click', R.autoFill);
  };

  function pt(e) {
    const r = R.cv.getBoundingClientRect();
    return { x: (e.clientX - r.left) * (R.size / r.width), y: (e.clientY - r.top) * (R.size / r.height) };
  }

  R.layout = function (keep) {
    const w = Math.min(window.innerWidth * 0.94, 520);
    const h = window.innerHeight * (U.isMobile() ? 0.5 : 0.56);
    const size = Math.floor(Math.max(240, Math.min(w, h)));
    const dpr = Math.min(window.devicePixelRatio || 1, 1.75);
    if (keep && size === R.size && R.layer) return;
    const old = R.layer;
    R.size = size; R.dpr = dpr; R.cx = size / 2; R.cy = size / 2; R.rad = size / 2 - 24;
    R.cv.width = Math.round(size * dpr); R.cv.height = Math.round(size * dpr);
    R.cv.style.width = size + 'px'; R.cv.style.height = size + 'px';
    R.ctx = R.cv.getContext('2d');
    R.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    R.layer = document.createElement('canvas');
    R.layer.width = R.cv.width; R.layer.height = R.cv.height;
    R.lctx = R.layer.getContext('2d');
    R.lctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (old) R.lctx.drawImage(old, 0, 0, size, size);
  };

  R.enter = function () {
    R.active = true;
    R.reset();
    R.layout(false);
    R.kick();
  };
  R.exit = function () {
    R.active = false;
    R.timers.forEach(clearTimeout);
    R.timers = [];
  };
  R.reset = function () {
    R.timers.forEach(clearTimeout);
    R.timers = [];
    R.stamps = 0;
    R.parts.length = 0;
    R.diyas = [];
    R.layout(false);
    R.lctx.clearRect(0, 0, R.size, R.size);
    hint();
  };

  function hint() {
    const el = U.$('#rgHint');
    if (!el) return;
    if (R.stamps === 0) el.textContent = 'Tap or drag to add petals. The pattern mirrors itself around the centre.';
    else if (R.stamps < 14) el.textContent = 'Lovely. Keep going and the lamps will wake up.';
    else if (R.stamps < 40) el.textContent = 'The diyas are glowing. Keep decorating.';
    else el.textContent = 'Beautiful. Your rangoli is complete.';
  }

  R.kick = function () {
    if (R.running) return;
    R.running = true;
    R.last = 0;
    requestAnimationFrame(frame);
  };

  function petal(c, x, y, ang, sz, col) {
    c.save(); c.translate(x, y); c.rotate(ang);
    const g = c.createLinearGradient(-sz, 0, sz * 1.1, 0);
    g.addColorStop(0, shade(col, -30)); g.addColorStop(0.55, col); g.addColorStop(1, shade(col, 40));
    c.fillStyle = g;
    c.beginPath(); c.moveTo(-sz * 0.8, 0); c.quadraticCurveTo(0, -sz * 0.75, sz * 1.1, 0); c.quadraticCurveTo(0, sz * 0.75, -sz * 0.8, 0); c.fill();
    c.strokeStyle = 'rgba(255,255,255,.35)'; c.lineWidth = 0.8; c.beginPath(); c.moveTo(-sz * 0.5, 0); c.lineTo(sz * 0.8, 0); c.stroke();
    c.restore();
  }
  function dot(c, x, y, sz, col) {
    c.fillStyle = col; c.beginPath(); c.arc(x, y, sz * 0.42, 0, TAU); c.fill();
    c.fillStyle = 'rgba(255,255,255,.55)'; c.beginPath(); c.arc(x - sz * 0.13, y - sz * 0.13, sz * 0.13, 0, TAU); c.fill();
  }
  function flower(c, x, y, ang, sz, col) {
    for (let i = 0; i < 5; i++) {
      const a = ang + (i / 5) * TAU;
      c.fillStyle = col; c.beginPath(); c.arc(x + Math.cos(a) * sz * 0.4, y + Math.sin(a) * sz * 0.4, sz * 0.3, 0, TAU); c.fill();
    }
    c.fillStyle = '#ffd23f'; c.beginPath(); c.arc(x, y, sz * 0.2, 0, TAU); c.fill();
  }
  function diamond(c, x, y, ang, sz, col) {
    c.save(); c.translate(x, y); c.rotate(ang); c.fillStyle = col;
    c.beginPath(); c.moveTo(sz * 0.6, 0); c.lineTo(0, sz * 0.34); c.lineTo(-sz * 0.6, 0); c.lineTo(0, -sz * 0.34); c.closePath(); c.fill();
    c.restore();
  }
  function shade(hex, amt) {
    const n = parseInt(hex.slice(1), 16);
    const f = (v) => U.clamp(v + amt, 0, 255);
    return 'rgb(' + f(n >> 16) + ',' + f((n >> 8) & 255) + ',' + f(n & 255) + ')';
  }

  R.stampAt = function (x, y, burst) {
    if (!R.lctx) return;
    const dx = x - R.cx, dy = y - R.cy;
    let r = Math.hypot(dx, dy);
    if (r > R.rad) r = R.rad;
    const th = Math.atan2(dy, dx);
    const kind = U.randi(0, 3);
    const col = U.pick(COLORS);
    const col2 = U.pick(COLORS);
    const sz = U.rand(9, 17) * (R.size / 420 + 0.45);
    const c = R.lctx;
    const n = r < 6 ? 1 : 8;
    for (let i = 0; i < n; i++) {
      for (const m of [1, -1]) {
        const a = m * th + (i * TAU) / 8;
        const px = R.cx + Math.cos(a) * r, py = R.cy + Math.sin(a) * r;
        if (kind === 0) petal(c, px, py, a, sz, col);
        else if (kind === 1) dot(c, px, py, sz, col);
        else if (kind === 2) flower(c, px, py, a, sz, col);
        else { diamond(c, px, py, a, sz, col); dot(c, px, py, sz * 0.5, col2); }
        if (r < 6) break;
      }
    }
    R.stamps++;
    // sparkle particles at the touch point
    for (let i = 0; i < (burst ? 9 : 3); i++) {
      R.parts.push({ x, y, vx: U.rand(-40, 40), vy: U.rand(-70, -10), life: U.rand(0.5, 1), max: 1, col: col, r: U.rand(1.2, 2.6) });
    }
    const want = Math.min(8, Math.floor(R.stamps / 4));
    while (R.diyas.length < want) R.diyas.push({ i: R.diyas.length, t: 0, ph: U.rand(0, TAU) });
    if (U.Audio.fx && (!R._snd || performance.now() - R._snd > 140)) {
      R._snd = performance.now();
      U.Audio.fx.bell(U.pick([784, 880, 988, 1175, 1319]), 0.06);
    }
    if (R.stamps === 40 && U.Audio.fx) U.Audio.fx.shimmer();
    hint();
    R.kick();
  };

  R.autoFill = function () {
    R.timers.forEach(clearTimeout);
    R.timers = [];
    const total = 56;
    for (let i = 0; i < total; i++) {
      R.timers.push(setTimeout(() => {
        if (!R.active) return;
        const a = U.rand(0, TAU), r = Math.sqrt(U.rand(0, 1)) * R.rad;
        R.stampAt(R.cx + Math.cos(a) * r, R.cy + Math.sin(a) * r, false);
      }, i * 55));
    }
  };

  function frame(now) {
    if (!R.active) { R.running = false; return; }
    const dt = R.last ? Math.min(0.05, (now - R.last) / 1000) : 0.016;
    R.last = now;
    const c = R.ctx, s = R.size, cx = R.cx, cy = R.cy, rad = R.rad;
    c.clearRect(0, 0, s, s);
    // floor disc
    const g = c.createRadialGradient(cx, cy, 0, cx, cy, rad + 14);
    g.addColorStop(0, '#2d1020'); g.addColorStop(0.8, '#1d0b16'); g.addColorStop(1, '#120610');
    c.fillStyle = g;
    c.beginPath(); c.arc(cx, cy, rad + 10, 0, TAU); c.fill();
    c.strokeStyle = 'rgba(245,192,74,.5)'; c.lineWidth = 1.5;
    c.beginPath(); c.arc(cx, cy, rad + 10, 0, TAU); c.stroke();
    // guide dots (visible while pattern is empty)
    const guide = Math.max(0, 1 - R.stamps / 24);
    if (guide > 0.02) {
      c.fillStyle = 'rgba(255,236,190,' + (0.28 * guide).toFixed(3) + ')';
      for (let ring = 1; ring <= 4; ring++) {
        const rr = (rad * ring) / 4.3, n = ring * 8;
        for (let i = 0; i < n; i++) { c.beginPath(); c.arc(cx + Math.cos((i / n) * TAU) * rr, cy + Math.sin((i / n) * TAU) * rr, 1.8, 0, TAU); c.fill(); }
      }
    }
    c.drawImage(R.layer, 0, 0, s, s);
    // diyas on the rim
    c.globalCompositeOperation = 'lighter';
    R.diyas.forEach((d) => {
      d.t = Math.min(1, d.t + dt * 0.7);
      const a = (d.i / 8) * TAU + Math.PI / 8;
      const x = cx + Math.cos(a) * (rad + 10), y = cy + Math.sin(a) * (rad + 10);
      const fl = 0.85 + 0.15 * Math.sin(now / 90 + d.ph) + 0.08 * Math.sin(now / 37 + d.ph * 2);
      const gr = c.createRadialGradient(x, y, 0, x, y, 38 * d.t);
      gr.addColorStop(0, 'rgba(255,200,90,' + 0.55 * fl * d.t + ')');
      gr.addColorStop(1, 'rgba(255,120,20,0)');
      c.fillStyle = gr; c.fillRect(x - 40, y - 40, 80, 80);
    });
    c.globalCompositeOperation = 'source-over';
    R.diyas.forEach((d) => {
      const a = (d.i / 8) * TAU + Math.PI / 8;
      const x = cx + Math.cos(a) * (rad + 10), y = cy + Math.sin(a) * (rad + 10);
      const fl = 0.85 + 0.15 * Math.sin(now / 90 + d.ph);
      const bg = c.createLinearGradient(x - 9, y, x + 9, y + 7);
      bg.addColorStop(0, '#ffe29a'); bg.addColorStop(1, '#8a560a');
      c.fillStyle = bg;
      c.beginPath(); c.ellipse(x, y + 2, 9, 5, 0, 0, Math.PI); c.fill();
      c.fillStyle = '#5b3508'; c.beginPath(); c.ellipse(x, y, 9, 3, 0, 0, TAU); c.fill();
      const fh = 10 * d.t * fl;
      const fg = c.createRadialGradient(x, y - 3, 0, x, y - 3, fh);
      fg.addColorStop(0, '#fffbe0'); fg.addColorStop(0.5, '#ffb52a'); fg.addColorStop(1, 'rgba(255,100,0,0)');
      c.fillStyle = fg;
      c.beginPath(); c.moveTo(x, y - 2); c.quadraticCurveTo(x - 4 * d.t, y - fh * 0.6, x, y - fh * 1.5); c.quadraticCurveTo(x + 4 * d.t, y - fh * 0.6, x, y - 2); c.fill();
    });
    // sparkles
    c.globalCompositeOperation = 'lighter';
    for (let i = R.parts.length - 1; i >= 0; i--) {
      const p = R.parts[i];
      p.life -= dt;
      if (p.life <= 0) { R.parts.splice(i, 1); continue; }
      p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 40 * dt;
      c.fillStyle = p.col;
      c.globalAlpha = Math.max(0, p.life / p.max);
      c.beginPath(); c.arc(p.x, p.y, p.r, 0, TAU); c.fill();
    }
    c.globalAlpha = 1;
    c.globalCompositeOperation = 'source-over';
    requestAnimationFrame(frame);
  }
})();
