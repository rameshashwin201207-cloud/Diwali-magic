# Diwali Universe 2026 · by R. Ashwin

A personalised, cinematic Diwali celebration. No build step and no installs needed.

## Run it
- Quick look: double-click `index.html` (works in Chrome/Edge/Firefox).
- Best for sharing: upload this whole folder to any static host (Netlify Drop, GitHub Pages, Vercel, Cloudflare Pages) and send the link.
- Local server (optional): `python3 -m http.server 8000` then open http://localhost:8000

## Music (your uploaded files, in `assets/audio/`)
| Scene | File |
|---|---|
| Opening, name question | `opening1.mp3` |
| Name reveal, countdown, fireworks, greeting, crackers | `celebration1.mp3` |
| Entrance, sweets, rangoli, diya, gift | `traditional.mp3` |
| Three little gods | `krishna-flute1.mp3` |
| Emotional ending | `emotional-ending.mp3` |

Only one track plays at a time: the old one fades out and stops before the next fades in. Music starts only after the first tap. If a file is missing the site stays silent for that scene and shows "Music file missing: <name>" (all five are present). The brief's names (`opening.mp3`, `celebration.mp3`, `krishna-flute.mp3`) are also accepted as fallbacks. To change a mapping, edit `TRACKS` at the top of `js/audio.js`.

## Sound effects
All cracker, bell, countdown and firework sounds are synthesised live with WebAudio (no downloads, no licence issues). Each cracker has its own sound.

## Optional upgrades
- Real sweet photos: add `kaju-katli.jpg`, `gulab-jamun.jpg`, `mysore-pak.jpg` to `assets/images/sweets/`. They replace the illustrations automatically.
- Offline fonts: fonts load from Google Fonts. Download Cormorant Garamond, Mulish and Noto Sans Tamil into `assets/fonts/` and add `@font-face` rules to self-host them. Without internet the site falls back to system serif/Tamil fonts.

## Privacy
The visitor's name, gender and relationship live only in memory for that page visit. Nothing is stored or sent anywhere.

## Files
`index.html` · `css/style.css` · `js/util.js` (dates, greetings, name matching) · `js/audio.js` · `js/fx.js` (sky, fireworks, particle text) · `js/crackers.js` · `js/rangoli.js` · `js/art.js` (SVG artwork) · `js/scenes.js` (journey)
